var SendDingTalkMessage = (function (_super) {
    __extends(SendDingTalkMessage, _super);
    function SendDingTalkMessage() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SendDingTalkMessage.prototype.execute = function () {
        // Get setings
        var commandSettings = this.CommandParam;
        var userId = commandSettings.UserId;
        var partyId = commandSettings.PartyId;
        var content = commandSettings.Content;
        var showError = commandSettings.ShowErrorMessage;
        var successMessage = commandSettings.SuccessMessage;

        userId = this.evaluateFormula(userId);
        partyId = this.evaluateFormula(partyId);
        content = this.evaluateFormula(content);
        successMessage = this.evaluateFormula(successMessage);

        Forguncy.Helper.post("customApi/dingtalk/sendTextMessage", JSON.stringify({ userId: userId, partyId: partyId, content: content }), function (message) {
            if (message)
            {
                if (showError)
                {
                    alert(message);
                }
            }
            else
            {
                if (successMessage)
                {
                    alert(successMessage);
                }
            }
        });
    }

    return SendDingTalkMessage;
}(Forguncy.CommandBase));

Forguncy.CommandFactory.registerCommand("SendDingTalkMessage.SendDingTalkMessage, SendDingTalkMessage", SendDingTalkMessage);