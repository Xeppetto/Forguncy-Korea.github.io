var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var ForguncyTreeCellType = (function (_super) {
        __extends(ForguncyTreeCellType, _super);
        function ForguncyTreeCellType() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.currentTreeValue = null;
            _this.nodeId = 1;
            _this.tableParamCache = {};
            return _this;
        }
        ForguncyTreeCellType.prototype.getValueFromElement = function () {
            return this.currentTreeValue;
        };
        ForguncyTreeCellType.prototype.setValueToElement = function (element, value) {
            if (this.currentTreeValue !== value) {
                this.currentTreeValue = value;
                this.updateTreeActiveState();
            }
            this.selectTreeNode(value);
        };
        ForguncyTreeCellType.prototype.selectTreeNode = function (value) {
            var treeObj = $.fn.zTree.getZTreeObj(this.ID + "_tree");
            var nodes = treeObj.transformToArray(treeObj.getNodes());
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].tag == value) {
                    treeObj.selectNode(nodes[i]);
                    return;
                }
            }
            var selectedNodes = treeObj.getSelectedNodes();
            if (selectedNodes.length > 0) {
                treeObj.cancelSelectedNode(selectedNodes[0]);
            }
        };
        ForguncyTreeCellType.prototype.createContent = function () {
            var container = $("<div id='" + this.ID + "' class=\"treeContainer\"/>");
            var ul = $("<ul id='" + this.ID + "_tree' class='ztree'></ul>");
            container.append(ul);
            this.addSelectedStyle(container);
            var self = this;
            this.onDependenceCellValueChanged(function (uiAction) {
                self.initZTree();
                self.selectTreeNode(self.currentTreeValue);
            });
            return container;
        };
        ForguncyTreeCellType.prototype.addSelectedStyle = function (container) {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var treeStyleInfo = cellTypeMetaData.TreeStyleInfo;
            if (treeStyleInfo) {
                if (treeStyleInfo.SelectedBackColor && treeStyleInfo.SelectedBackColor != "") {
                    container.append($("<style> #" + this.ID + "_tree li a.curSelectedNode { background:" + Forguncy.ConvertToCssColor(treeStyleInfo.SelectedBackColor) + ";}</style>"));
                }
                if (treeStyleInfo.SelectedForeColor && treeStyleInfo.SelectedForeColor != "") {
                    container.append($("<style> #" + this.ID + "_tree li a.curSelectedNode { color:" + Forguncy.ConvertToCssColor(treeStyleInfo.SelectedForeColor) + ";}</style>"));
                }
            }
        };
        ForguncyTreeCellType.prototype.setFontStyle = function (styleInfo) {
            var ul = $("#" + this.ID + "_tree");
            if (styleInfo.FontFamily) {
                ul.css("font-family", styleInfo.FontFamily);
            }
            else {
                ul.css("font-family", Forguncy.LocaleFonts.default);
            }
            if (styleInfo.FontSize && styleInfo.FontSize > 0) {
                ul.css("font-size", styleInfo.FontSize);
                var lineHeight = Math.ceil(styleInfo.FontSize + 8);
                ul.find("li").css("line-height", lineHeight + "px");
                ul.find("li span").css("line-height", lineHeight + "px");
            }
            if (styleInfo.Foreground && styleInfo.Foreground !== "") {
                ul.css("color", Forguncy.ConvertToCssColor(styleInfo.Foreground));
            }
        };
        ForguncyTreeCellType.prototype.getTreeSettings = function () {
            var self = this;
            var setting = {
                view: {
                    showLine: false,
                    dblClickExpand: false
                },
                data: {
                    simpleData: {
                        enable: true
                    }
                },
                callback: {
                    onClick: function (e, treeId, treeNode) {
                        if (treeNode.tag !== self.currentTreeValue) {
                            self.currentTreeValue = treeNode.tag;
                            self.updateTreeActiveState();
                            self.commitValue();
                        }
                        var commands = self.CellElement.CellType.CommandList;
                        if (commands != null && commands.length > 0) {
                            self.executeCommand(commands);
                        }
                    }
                }
            };
            return setting;
        };
        ForguncyTreeCellType.prototype.getTreeNodes = function () {
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            var bindingTreeLevelInfo = cellTypeMetaData.BindingTreeLevelInfo;
            var isBinding = cellTypeMetaData.IsBinding;
            var treeBindingMode = cellTypeMetaData.TreeBindingMode;
            var items = cellTypeMetaData.Items;
            if (isBinding === true) {
                this.tableParamCache = {};
                this.addTableParamInfo(bindingTreeLevelInfo);
                if (treeBindingMode === 1) {
                    return this.getTreeNodesInDynamicMode(bindingTreeLevelInfo);
                }
                items = this.getBindingItemsInFixLevelMode(bindingTreeLevelInfo, null, "");
            }
            if (items == null || items.length === 0) {
                return [];
            }
            var nodes = this.convertItemsToTreeNodes(items, null, "");
            return nodes;
        };
        ForguncyTreeCellType.prototype.addTableParamInfo = function (bindingTreeLevelInfo) {
            if (!bindingTreeLevelInfo) {
                return;
            }
            var tableName = bindingTreeLevelInfo.TableName;
            if (this.isEmpty(tableName)) {
                return;
            }
            var columns = [];
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.NameColumn);
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.ValueColumn);
            this.addTableColumnParamInfo(columns, bindingTreeLevelInfo.MasterTableReletedColumn);
            var param = {
                TableName: tableName,
                Columns: columns,
                QueryCondition: bindingTreeLevelInfo.QueryCondition,
                QueryPolicy: {
                    Distinct: false,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: bindingTreeLevelInfo.SortCondition
            };
            var postParamWithoutQuery = {
                TableName: tableName,
                Columns: columns,
                QueryPolicy: {
                    Distinct: false,
                    QueryNullPolicy: Forguncy.QueryNullPolicy.QueryAllItemsWhenValueIsNull,
                    IgnoreCache: false
                },
                SortCondition: bindingTreeLevelInfo.SortCondition
            };
            if (!this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)]) {
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)] = {};
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParam = param;
                this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParamWithoutQuery = postParamWithoutQuery;
            }
            this.addTableParamInfo(bindingTreeLevelInfo.SubBindingTreeLevelInfo);
        };
        ForguncyTreeCellType.prototype.isEmpty = function (obj) {
            if (obj === null || obj === "" || obj === undefined) {
                return true;
            }
            return false;
        };
        ForguncyTreeCellType.prototype.addTableColumnParamInfo = function (list, columnName) {
            if (!this.isEmpty(columnName) && list.indexOf(columnName) === -1) {
                list.push(columnName);
            }
        };
        ForguncyTreeCellType.prototype.getBindingItemsInFixLevelMode = function (bindingTreeLevelInfo, masterTableRelatedColumnValue, tag) {
            if (!bindingTreeLevelInfo || this.isEmpty(bindingTreeLevelInfo.TableName)) {
                return null;
            }
            var postParam = this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)].postParam;
            var tableData = this.getTableDataByCondition(postParam);
            var items = [];
            if (tableData != null) {
                var flags = {};
                for (var i = 0; i < tableData.length; i++) {
                    if (bindingTreeLevelInfo.MasterTableReletedColumn) {
                        var mRCvalue = tableData[i][bindingTreeLevelInfo.MasterTableReletedColumn];
                        if (masterTableRelatedColumnValue != null) {
                            if (mRCvalue !== masterTableRelatedColumnValue) {
                                continue;
                            }
                        }
                    }
                    var value = tableData[i][bindingTreeLevelInfo.ValueColumn];
                    if (value == null || flags[tag + "_" + value] === true) {
                        continue;
                    }
                    flags[tag + "_" + value] = true;
                    var itemInfo = {};
                    var text = tableData[i][bindingTreeLevelInfo.NameColumn];
                    if (text === undefined || text === null) {
                        text = "";
                    }
                    itemInfo.Text = text;
                    itemInfo.Value = value;
                    var detailTableReletedColumnValue = value;
                    if (bindingTreeLevelInfo.SubBindingTreeLevelInfo) {
                        var subItems = this.getBindingItemsInFixLevelMode(bindingTreeLevelInfo.SubBindingTreeLevelInfo, detailTableReletedColumnValue, tag + "_" + value);
                        if (subItems != null) {
                            itemInfo.SubItems = subItems;
                        }
                    }
                    items.push(itemInfo);
                }
            }
            return items;
        };
        ForguncyTreeCellType.prototype.getTableDataByCondition = function (postParam) {
            var tableData = null;
            Forguncy.getTableDataByCondition(postParam, this.getFormulaCalcContext(), function (dataStr) {
                if (dataStr) {
                    tableData = JSON.parse(dataStr);
                }
            }, false);
            return tableData;
        };
        ForguncyTreeCellType.prototype.getTreeNodesInDynamicMode = function (bindingTreeLevelInfo) {
            var paramInfo = this.tableParamCache[JSON.stringify(bindingTreeLevelInfo)];
            var postParam = paramInfo.postParam;
            var postParamWithoutQuery = paramInfo.postParamWithoutQuery;
            var allTableData = this.getTableDataByCondition(postParamWithoutQuery);
            var tableData = this.getTableDataByCondition(postParam);
            if (tableData != null) {
                var flags = [];
                for (var i = 0; i < tableData.length; i++) {
                    var value = tableData[i][bindingTreeLevelInfo.ValueColumn];
                    var pId = tableData[i][bindingTreeLevelInfo.MasterTableReletedColumn];
                    if (!this.isEmpty(pId)) {
                        if (value === pId) {
                            continue;
                        }
                        this.addParentIfNotExistInDynamicMode(bindingTreeLevelInfo, allTableData, pId, flags);
                    }
                    if (flags.indexOf(value) === -1) {
                        flags.push(value);
                    }
                }
                var nodes = [];
                for (var i = 0; i < allTableData.length; i++) {
                    var value = allTableData[i][bindingTreeLevelInfo.ValueColumn];
                    if (flags.indexOf(value) === -1) {
                        continue;
                    }
                    var text = allTableData[i][bindingTreeLevelInfo.NameColumn];
                    var pId = allTableData[i][bindingTreeLevelInfo.MasterTableReletedColumn];
                    nodes.push({
                        id: value,
                        value: value,
                        name: text,
                        pId: this.isEmpty(pId) ? null : pId,
                        tag: value
                    });
                }
                return nodes;
            }
            return null;
        };
        ForguncyTreeCellType.prototype.addParentIfNotExistInDynamicMode = function (bindingTreeLevelInfo, tableData, pId, flags) {
            for (var i = 0; i < tableData.length; i++) {
                var val = tableData[i][bindingTreeLevelInfo.ValueColumn];
                if (val == pId) {
                    if (flags.indexOf(val) === -1) {
                        flags.push(val);
                    }
                    var cur_pId = tableData[i][bindingTreeLevelInfo.MasterTableReletedColumn];
                    if (!this.isEmpty(cur_pId)) {
                        if (cur_pId === pId) {
                            continue;
                        }
                        this.addParentIfNotExistInDynamicMode(bindingTreeLevelInfo, tableData, cur_pId, flags);
                    }
                    break;
                }
            }
        };
        ForguncyTreeCellType.prototype.convertItemsToTreeNodes = function (items, pId, pTag) {
            if (items != null && items.length > 0) {
                var nodes = [];
                for (var i = 0; i < items.length; i++) {
                    var item = items[i];
                    var node = {
                        id: this.nodeId++,
                        value: item.Value,
                        name: item.Text,
                        pId: pId,
                        tag: pTag === "" ? item.Value : (pTag + "_" + item.Value)
                    };
                    nodes.push(node);
                    var subNodes = this.convertItemsToTreeNodes(item.SubItems, node.id, node.tag);
                    if (subNodes != null && subNodes.length > 0) {
                        for (var k = 0; k < subNodes.length; k++) {
                            nodes.push(subNodes[k]);
                        }
                    }
                }
                return nodes;
            }
            return null;
        };
        ForguncyTreeCellType.prototype.onLoad = function () {
            $("#" + this.ID).parent("div").css("overflow", "auto");
            this.initZTree();
        };
        ForguncyTreeCellType.prototype.initZTree = function () {
            $.fn.zTree.init($("#" + this.ID + "_tree"), this.getTreeSettings(), this.getTreeNodes());
            var element = this.CellElement;
            var cellTypeMetaData = element.CellType;
            if (cellTypeMetaData.DefaultExpandStyle === 0) {
                var tree = $.fn.zTree.getZTreeObj(this.ID + "_tree");
                tree.expandAll(true);
            }
            this.setFontStyle(element.StyleInfo);
        };
        ForguncyTreeCellType.prototype.getDefaultValue = function () {
            var currentTreeActiveState = this.getTreeActiveState();
            if (currentTreeActiveState) {
                return {
                    Value: currentTreeActiveState
                };
            }
            return null;
        };
        ForguncyTreeCellType.prototype.getTreeActiveState = function () {
            var pageName = this.IsInMasterPage === true ? Forguncy.Page.getMasterPageName() : Forguncy.Page.getPageName();
            if (ForguncyTreeCellType.treeStorage == null || ForguncyTreeCellType.treeStorage[pageName] == null || ForguncyTreeCellType.treeStorage[pageName][this.ID] == null) {
                return;
            }
            var currentTreeStorage = ForguncyTreeCellType.treeStorage[pageName][this.ID];
            return currentTreeStorage["active_treeNode"];
        };
        ForguncyTreeCellType.prototype.updateTreeActiveState = function () {
            if (ForguncyTreeCellType.treeStorage == null) {
                ForguncyTreeCellType.treeStorage = {};
            }
            var pageName = this.IsInMasterPage === true ? Forguncy.ForguncyData.pageInfo.masterPageName : Forguncy.ForguncyData.pageInfo.pageName;
            if (ForguncyTreeCellType.treeStorage[pageName] == null) {
                ForguncyTreeCellType.treeStorage[pageName] = {};
            }
            if (ForguncyTreeCellType.treeStorage[pageName][this.ID] == null) {
                ForguncyTreeCellType.treeStorage[pageName][this.ID] = [];
            }
            ForguncyTreeCellType.treeStorage[pageName][this.ID]["active_treeNode"] = this.currentTreeValue;
        };
        ForguncyTreeCellType.prototype.getBindingTables = function () {
            var cellTypeMetaData = this.CellElement.CellType;
            var isBinding = cellTypeMetaData.IsBinding;
            var bindingTreeLevelInfo = cellTypeMetaData.BindingTreeLevelInfo;
            if (!isBinding || !bindingTreeLevelInfo) {
                return null;
            }
            var result = [];
            var treeBindingMode = cellTypeMetaData.TreeBindingMode;
            if (treeBindingMode == 1) {
                result.push(bindingTreeLevelInfo.TableName);
            }
            else {
                this.addRelatedTables(bindingTreeLevelInfo, result);
            }
            return result;
        };
        ForguncyTreeCellType.prototype.addRelatedTables = function (bindingTreeLevelInfo, list) {
            if (bindingTreeLevelInfo) {
                list.push(bindingTreeLevelInfo.TableName);
                this.addRelatedTables(bindingTreeLevelInfo.SubBindingTreeLevelInfo, list);
            }
        };
        ForguncyTreeCellType.prototype.reload = function () {
            var isReload = arguments[0];
            if (isReload) {
                this.initZTree();
                this.selectTreeNode(this.currentTreeValue);
            }
        };
        ForguncyTreeCellType.treeStorage = {};
        return ForguncyTreeCellType;
    }(Forguncy.Plugin.CellTypeBase));
    Forguncy.ForguncyTreeCellType = ForguncyTreeCellType;
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("Forguncy.CustomMenu.ForguncyTreeCellType, Forguncy.CustomMenu", Forguncy.ForguncyTreeCellType);
