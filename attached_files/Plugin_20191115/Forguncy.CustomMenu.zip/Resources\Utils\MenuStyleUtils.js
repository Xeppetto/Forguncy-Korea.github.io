var Forguncy;
(function (Forguncy) {
    var MenuStyleUtils = (function () {
        function MenuStyleUtils() {
        }
        MenuStyleUtils.InsertRule = function (pageName, cssSelector, ruleStr) {
            if (!MenuStyleUtils.MenuStyleSheet) {
                return false;
            }
            var ruleId = [pageName, cssSelector, ruleStr].join('*');
            if (MenuStyleUtils.UsedRuleCache[ruleId]) {
                return false;
            }
            MenuStyleUtils.MenuStyleSheet.insertRule(cssSelector + " " + ruleStr, 0);
            MenuStyleUtils.UsedRuleCache[ruleId] = true;
            return true;
        };
        MenuStyleUtils.InsertArrowFillColorRule = function (pageName, cssSelector, fillColor, useImportant) {
            if (useImportant === void 0) { useImportant = true; }
            var ruleStr = "{fill: " + fillColor + " " + (useImportant ? '!important' : '') + ";}";
            return MenuStyleUtils.InsertRule(pageName, cssSelector, ruleStr);
        };
        MenuStyleUtils.InsertForeColorRule = function (pageName, cssSelector, foreColor, useImportant) {
            if (useImportant === void 0) { useImportant = true; }
            var ruleStr = "{color: " + foreColor + " " + (useImportant ? '!important' : '') + ";}";
            return MenuStyleUtils.InsertRule(pageName, cssSelector, ruleStr);
        };
        MenuStyleUtils.InsertBackColorRule = function (pageName, cssSelector, backgroundColor, useImportant) {
            if (useImportant === void 0) { useImportant = true; }
            var ruleStr = "{background: " + backgroundColor + " border-box " + (useImportant ? '!important' : '') + ";}";
            return MenuStyleUtils.InsertRule(pageName, cssSelector, ruleStr);
        };
        MenuStyleUtils.UsedRuleCache = {};
        return MenuStyleUtils;
    }());
    Forguncy.MenuStyleUtils = MenuStyleUtils;
})(Forguncy || (Forguncy = {}));
