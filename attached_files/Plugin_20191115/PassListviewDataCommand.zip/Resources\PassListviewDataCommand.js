var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var PassListviewDataCommand;
(function (PassListviewDataCommand_1) {
    var PassListviewDataCommand = /** @class */ (function (_super) {
        __extends(PassListviewDataCommand, _super);
        function PassListviewDataCommand() {
            var _this = _super.call(this) || this;
            if (!PassListviewDataCommand.hasBindPageEvent) {
                PassListviewDataCommand.hasBindPageEvent = true;
                Forguncy.Page.bind(Forguncy.PageEvents.PageDefaultDataLoaded, PassListviewDataCommand.onCurrentPageChanged, "*");
                Forguncy.Page.bind(Forguncy.PageEvents.PopupClosed, PassListviewDataCommand.onCurrentPageChanged, "*");
            }
            return _this;
        }
        PassListviewDataCommand.onCurrentPageChanged = function (arg1, arg2) {
            PassListviewDataCommand.cache.forEach(function (data) {
                return PassListviewDataCommand.tryToPassDataToCurrentPage(data.TargetPage, data.TargetCells, data.Data);
            });
            PassListviewDataCommand.cache = [];
        };
        PassListviewDataCommand.prototype.execute = function () {
            var commandSettings = this.CommandParam;
            var passItems = commandSettings.PassValueItems;
            if (!passItems || passItems.length === 0) {
                return;
            }
            var sourceCells = this.getCellLocationOrColumnNames(passItems.map(function (i) { return i.SourceCell; }));
            var targetCells = this.getCellLocationOrColumnNames(passItems.map(function (i) { return i.TargetCell; }));
            var sourceListviewData = this.getSourceListviewData(sourceCells, commandSettings.PassRowMode);
            if (sourceListviewData.length === 0) {
                return;
            }
            var success = PassListviewDataCommand.tryToPassDataToCurrentPage(commandSettings.TargetPage, targetCells, sourceListviewData);
            if (!success) {
                PassListviewDataCommand.cache.push({
                    TargetPage: commandSettings.TargetPage,
                    TargetCells: targetCells,
                    Data: sourceListviewData
                });
            }
        };
        PassListviewDataCommand.prototype.getCellLocationOrColumnNames = function (cells) {
            var cellLocationOrColumnNames = [];
            if (cells) {
                for (var i = 0; i < cells.length; i++) {
                    var cell = cells[i];
                    if (typeof (cell) === "string" && cell.length > 0 && cell[0] === "=") {
                        cell = this.getCellLocation(cells[i]);
                    }
                    cellLocationOrColumnNames.push(cell);
                }
            }
            return cellLocationOrColumnNames;
        };
        PassListviewDataCommand.tryToPassDataToCurrentPage = function (targetPageName, targetCells, sourceListviewData) {
            if (PassListviewDataCommand.isTargetListviewInCurrentPage(targetPageName, targetCells)) {
                PassListviewDataCommand.addDataToTargetListview(targetCells, sourceListviewData, null);
                return true;
            }
            var subPageInfo = PassListviewDataCommand.getTargetSubPageInfo(targetPageName, targetCells);
            if (subPageInfo) {
                PassListviewDataCommand.addDataToTargetListview(targetCells, sourceListviewData, subPageInfo);
                return true;
            }
            return false;
        };
        PassListviewDataCommand.isTargetListviewInCurrentPage = function (targetPageName, targetCells) {
            if (Forguncy.Page.getPageName() === targetPageName) {
                return true;
            }
            if (!targetPageName) {
                return !!PassListviewDataCommand.getListview(targetCells, null);
            }
            return false;
        };
        PassListviewDataCommand.getTargetSubPageInfo = function (targetPageName, targetCells, pageInfo) {
            if (pageInfo === void 0) { pageInfo = null; }
            var containers = pageInfo ? pageInfo.getContainerCells() : Forguncy.Page.getContainerCells(false);
            for (var i = 0; i < containers.length; i++) {
                var subPageInfos = void 0;
                if (containers[i].constructor === Forguncy.ContentContainerCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfContentContainerCell(containers[i]);
                }
                else if (containers[i].constructor === Forguncy.TabControlCell) {
                    subPageInfos = PassListviewDataCommand.getSubPagesOfTabControlCell(containers[i]);
                }
                else {
                    subPageInfos = [];
                }
                for (var k = 0; k < subPageInfos.length; k++) {
                    var subPageInfo = subPageInfos[k];
                    if (PassListviewDataCommand.isTargetListviewInSubPage(targetPageName, targetCells, subPageInfo)) {
                        return subPageInfo;
                    }
                    var target = PassListviewDataCommand.getTargetSubPageInfo(targetPageName, targetCells, subPageInfo);
                    if (target) {
                        return target;
                    }
                }
            }
            return null;
        };
        PassListviewDataCommand.getSubPagesOfContentContainerCell = function (cell) {
            return [cell.getContentPage()];
        };
        PassListviewDataCommand.getSubPagesOfTabControlCell = function (cell) {
            var subPageInfos = [];
            var tabCount = cell.getTabCount();
            for (var k = 0; k < tabCount; k++) {
                subPageInfos.push(cell.getTabPage(k));
            }
            return subPageInfos;
        };
        PassListviewDataCommand.isTargetListviewInSubPage = function (targetPageName, targetCells, subPageInfo) {
            if (!subPageInfo) {
                return false;
            }
            if (subPageInfo.getPageName() === targetPageName) {
                return true;
            }
            if (!targetPageName) {
                return !!PassListviewDataCommand.getListview(targetCells, subPageInfo);
            }
        };
        PassListviewDataCommand.prototype.getSourceListviewData = function (sourceCells, passRowMode) {
            var pageID = this.getFormulaCalcContext().PageID;
            var listview = PassListviewDataCommand.getListview(sourceCells, Forguncy.Page.getSubPageInfoByPageID(pageID));
            if (!listview) {
                return [];
            }
            var columns = PassListviewDataCommand.getColumns(listview, sourceCells);
            switch (passRowMode) {
                case PassRowMode.SelectedRows:
                    return this.getSourceListviewDataOfSelectedRows(listview, columns);
                case PassRowMode.CurrentRow:
                    return this.getSourceListviewDataOfCurrentRow(listview, columns);
                default:
                    return this.getSourceListviewDataOfAllRows(listview, columns);
            }
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfSelectedRows = function (listview, columns) {
            var selectedRowsData = listview.getSelectedRowsData();
            if (selectedRowsData.length === 1 && !listview.isSelectedRow(listview.getSelectedRowIndex())) {
                //When listview don't have selected column, and no selected row, selectedRowsData will contain current row.
                return [];
            }
            return selectedRowsData.map(function (d) {
                return columns.map(function (c) {
                    if (c === -1) {
                        return null;
                    }
                    else {
                        return d.Values[c];
                    }
                });
            });
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfCurrentRow = function (listview, columns) {
            var currentRowIndex = listview.getSelectedRowIndex();
            var rowCount = listview.getRowCount();
            if (currentRowIndex === undefined || currentRowIndex < 0 || currentRowIndex >= rowCount) {
                return [];
            }
            return [this.getRowDataFromListview(listview, columns, currentRowIndex)];
        };
        PassListviewDataCommand.prototype.getSourceListviewDataOfAllRows = function (listview, columns) {
            var data = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                data.push(this.getRowDataFromListview(listview, columns, r));
            }
            return data;
        };
        PassListviewDataCommand.prototype.getRowDataFromListview = function (listview, columns, rowIndex) {
            return columns.map(function (c) {
                return c === -1 ? null : listview.getValue(rowIndex, c);
            });
        };
        PassListviewDataCommand.getListview = function (cells, pageInfo) {
            var firstCellLocation;
            for (var i = 0; i < cells.length; i++) {
                if (typeof (cells[i]) === "object") {
                    firstCellLocation = cells[i];
                    break;
                }
            }
            var firstColumnName;
            for (var i = 0; i < cells.length; i++) {
                if (typeof (cells[i]) === "string" && cells[i]) {
                    firstColumnName = cells[i];
                    break;
                }
            }
            if (!firstCellLocation && !firstColumnName) {
                return null;
            }
            var listViews = pageInfo ? pageInfo.getListViews() : Forguncy.Page.getListViews(false);
            for (var i = 0; i < listViews.length; i++) {
                if (firstCellLocation) {
                    if (PassListviewDataCommand.isListviewContainCellLocation(listViews[i], firstCellLocation)) {
                        return listViews[i];
                    }
                }
                else if (firstColumnName) {
                    if (PassListviewDataCommand.isListviewContainColumnName(listViews[i], firstColumnName)) {
                        return listViews[i];
                    }
                }
            }
            return null;
        };
        PassListviewDataCommand.isListviewContainCellLocation = function (listview, cellLocation) {
            var rangeInfo = listview.getDesignerRangeInfo();
            return cellLocation.Row >= rangeInfo.Row &&
                cellLocation.Row < rangeInfo.Row + rangeInfo.RowCount &&
                cellLocation.Column >= rangeInfo.Column &&
                cellLocation.Column < rangeInfo.Column + rangeInfo.ColumnCount;
        };
        PassListviewDataCommand.isListviewContainColumnName = function (listview, columnName) {
            return PassListviewDataCommand.getColumnIndex(listview, columnName) !== -1;
        };
        PassListviewDataCommand.getColumnIndex = function (listview, cell) {
            var columns = listview.getMergedColumnInfos();
            if (!cell) {
                return -1;
            }
            else if (typeof (cell) === "string") {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].ColumnName === cell) {
                        return i;
                    }
                }
                return -1;
            }
            else {
                for (var i = 0; i < columns.length; i++) {
                    if (columns[i].DesignerColumnIndex === cell.Column) {
                        return i;
                    }
                }
                return -1;
            }
        };
        PassListviewDataCommand.getColumns = function (listview, cells) {
            var columns = [];
            for (var i = 0; i < cells.length; i++) {
                columns.push(PassListviewDataCommand.getColumnIndex(listview, cells[i]));
            }
            return columns;
        };
        PassListviewDataCommand.addDataToTargetListview = function (targetCells, data, pageInfo) {
            var listview = PassListviewDataCommand.getListview(targetCells, pageInfo);
            if (!listview) {
                return;
            }
            var columns = PassListviewDataCommand.getColumns(listview, targetCells);
            try {
                Forguncy.Page.suspendCalc();
                for (var r = 0; r < data.length; r++) {
                    var rowData = [];
                    for (var c = 0; c < columns.length; c++) {
                        if (columns[c] === -1) {
                            continue;
                        }
                        rowData[columns[c]] = data[r][c];
                    }
                    listview.addNewRow(rowData);
                }
            }
            finally {
                Forguncy.Page.resumeCalc();
            }
        };
        PassListviewDataCommand.hasBindPageEvent = false;
        PassListviewDataCommand.cache = [];
        return PassListviewDataCommand;
    }(Forguncy.Plugin.CommandBase));
    PassListviewDataCommand_1.PassListviewDataCommand = PassListviewDataCommand;
    var PassRowMode;
    (function (PassRowMode) {
        PassRowMode[PassRowMode["AllRows"] = 0] = "AllRows";
        PassRowMode[PassRowMode["SelectedRows"] = 1] = "SelectedRows";
        PassRowMode[PassRowMode["CurrentRow"] = 2] = "CurrentRow";
    })(PassRowMode || (PassRowMode = {}));
})(PassListviewDataCommand || (PassListviewDataCommand = {}));
Forguncy.Plugin.CommandFactory.registerCommand("PassListviewDataCommand.PassListviewDataCommand, PassListviewDataCommand", PassListviewDataCommand.PassListviewDataCommand);
