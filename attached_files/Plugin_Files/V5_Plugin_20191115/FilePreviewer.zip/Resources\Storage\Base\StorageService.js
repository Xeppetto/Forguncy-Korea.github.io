var FilePreviewer;
(function (FilePreviewer) {
    var ProgressData = (function () {
        function ProgressData() {
        }
        return ProgressData;
    }());
    FilePreviewer.ProgressData = ProgressData;
    var SuccessData = (function () {
        function SuccessData() {
        }
        return SuccessData;
    }());
    FilePreviewer.SuccessData = SuccessData;
    var FailData = (function () {
        function FailData() {
        }
        return FailData;
    }());
    FilePreviewer.FailData = FailData;
    var Transmit = (function () {
        function Transmit() {
        }
        return Transmit;
    }());
    FilePreviewer.Transmit = Transmit;
})(FilePreviewer || (FilePreviewer = {}));
