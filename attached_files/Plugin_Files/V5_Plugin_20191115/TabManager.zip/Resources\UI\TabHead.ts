﻿namespace TabManager {

    export const enum TabHeadClassNames {
        Nav = "FTM-nav",
        NavPrev = "FTM-nav-prev",
        NavNext = "FTM-nav-next",
        NavMenu = "FTM-nav-menu",
        NavWrap = "FTM-nav-wrap",
        NavPlaceholder = "FTM-nav-wrap-placeholder", // 移动tab时 margin-left的调整只发生在此placeholder上
        NavList = "FTM-nav-wrap-list",
        NavListItem = "FTM-nav-wrap-list-item",
        NavListItemLink = "FTM-nav-wrap-list-item-link",
        NavListItemClose = "FTM-nav-wrap-list-item-close",
        NavMenuWrap = "FTM-nav-menu-wrap",
        NavMenuList = "FTM-nav-menu-wrap-list",
        NavMenuListItem = "FTM-nav-menu-wrap-list-item",
        // modifier
        Active = "selected",
    }

    export class TabHeadUI extends ControlUIBase<TabContainer> {
        navPrev: JQuery;
        navNext: JQuery;
        navWrap: JQuery;
        navMenu: JQuery;

        static readonly navStep = 500;
        static readonly aminateSpeed = 150;

        set activeTab(value: Tab) {
            this.navWrap.find(`.${TabHeadClassNames.NavListItem}`).removeClass(TabHeadClassNames.Active);
            if (value) {
                const activeTab = this.navWrap.find(`.${TabHeadClassNames.NavListItem}[data-uid="${value.uid}"]`);
                activeTab.addClass(TabHeadClassNames.Active);
                this.revealItem(activeTab);
            }
        }

        // override
        protected createContainer(): void {
            this.container = $(`<div class="${TabHeadClassNames.Nav}"></div>`);
        }

        protected createContainerEvents(): void {
            super.createContainerEvents();

            this.target.on(TabManagerEvents.TabsChanged, () => {
                this.createTabs();
                this.toggleContainer();
            });

            this.target.on(TabManagerEvents.WindowResized, () => {
                this.updateNav();
            });
        }

        get hasEnoughWidth(): boolean {
            const containerWidth = this.container[0].clientWidth;
            let tabItemsTotalWidth = 0;
            this.navWrap
                .find(`.${TabHeadClassNames.NavListItem}`)
                .each((index: number, el:Element) => {
                    tabItemsTotalWidth += $(el).width();
                });
            return tabItemsTotalWidth <= containerWidth;
        }

        // override
        protected createChildren(): void {

            this.navPrev = $(`<div class='${TabHeadClassNames.NavPrev}'></div>`);
            this.navNext = $(`<div class='${TabHeadClassNames.NavNext}'></div>`);
            this.navMenu = this.target.createUI(TabMenuUI).container;

            this.navPrev.on('click', () => {
                this.movePrev();
            });

            this.navNext.on('click', () => {
                this.moveNext();
            });

            this.navWrap = $(`
<nav class="${TabHeadClassNames.NavWrap}">
    <div class="${TabHeadClassNames.NavPlaceholder}"><ul class="${TabHeadClassNames.NavList}"></ul></div>
</nav>`);

            this.createTabs();

            this.container.append(
                this.navPrev,
                this.navNext,
                this.navWrap,
                this.navMenu); // 如果append的是null，则实际上什么也没append到DOM
        }

        get styleTemplateClassName() {
            if (!this.target.tabStyle) {
                return "";
            }
            return `TabManagerTabCellType-${this.target.tabStyle.Key}-TabItem`;
        }

        private revealItem(item: JQuery): void {
            if (item.length === 0) {
                return;
            }

            const navWrapOffsetLeft = this.navWrap.offset().left;
            const navWrapWidth = this.navWrap.width(); // tab导航的固定宽度
            const itemOffsetLeft = item.offset().left;
            const itemWidth = item.width();

            const placeholder = this.navWrap.find(`.${TabHeadClassNames.NavPlaceholder}`);
            const currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            let usedMarginLeft = currentMarginLeft;

            if (itemOffsetLeft < navWrapOffsetLeft) {
                // item在左侧 被遮挡
                usedMarginLeft += navWrapOffsetLeft - itemOffsetLeft;
            } else if (navWrapOffsetLeft + navWrapWidth <= itemOffsetLeft + itemWidth) {
                // item在右侧 被遮挡
                usedMarginLeft -= itemOffsetLeft + itemWidth - navWrapOffsetLeft - navWrapWidth;
            }

            placeholder.animate({
                "margin-left": `${usedMarginLeft}px`
            }, TabHeadUI.aminateSpeed);
        }

        private moveNext(): void {
            const placeholder = this.navWrap.find(`.${TabHeadClassNames.NavPlaceholder}`);
            const navWrapWidth = this.navWrap.width(); // tab导航的固定宽度
            const navListWidth = this.navWrap.find(`.${TabHeadClassNames.NavList}`).width(); // list的实际总宽度

            if (navListWidth <= navWrapWidth) {
                return;
            }

            const currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            const marginLeftLimit = navListWidth - navWrapWidth; // 最多允许的 margin-left
            const targetMarginLeft = currentMarginLeft - TabHeadUI.navStep; // 根据step算出的将要移动至的 margin-left
            const usedMarginLeft = Math.max(-marginLeftLimit, targetMarginLeft);

            placeholder.animate({
                "margin-left": `${usedMarginLeft}px`
            }, TabHeadUI.aminateSpeed);
        }

        private movePrev(): void {
            const placeholder = this.navWrap.find(`.${TabHeadClassNames.NavPlaceholder}`);
            const currentMarginLeft = parseFloat(placeholder.css('margin-left')); // 未移动之前的 当前margin-left
            const targetMarginLeft = currentMarginLeft + TabHeadUI.navStep; // 根据step算出的将要移动至的 margin-left
            const usedMarginLeft = Math.min(0, targetMarginLeft); // margin-left 不能为正值 即不会右移动

            placeholder.animate({
                "margin-left": `${usedMarginLeft}px`
            }, TabHeadUI.aminateSpeed);
        }

        private createTabs(): void {
            const newTabs = this.target.tabList.map(v => {

                const link = $(`<a class="${TabHeadClassNames.NavListItemLink} ${FragmentClassNames.Ellipsis}"></a>`);
                link.text(v.displayedTitle);
                const tab = $(`<li data-uid="${v.uid}" class="${TabHeadClassNames.NavListItem} ${this.styleTemplateClassName}"></li>`)
                    .on("click", () => {
                        this.target.active(v);
                    });
                tab.attr("title", v.displayedTitle).append(link);

                if (v === this.target.activeTab) {
                    tab.addClass(TabHeadClassNames.Active);
                }

                if (v.canBeClosed) {
                    const close = $(`<i class="${TabHeadClassNames.NavListItemClose}"></i>`).on("click", () => {
                        this.target.closeTab(v);
                    });
                    tab.find(`.${TabHeadClassNames.NavListItemLink}`).append(close);
                }

                return tab;
            });

            const navList = this.navWrap.find(`.${TabHeadClassNames.NavList}`);
            navList.empty();
            navList.append(...newTabs);

            this.updateNav();
        }

        /**
         * 在没有任何tab的时候 不显示container
         * related to Bug 29759
         */
        private toggleContainer(): void {
            const container = $(`.${TabContainerClassNames.Container}`);
            const opacity = (this.target.tabList && this.target.tabList.length > 0) ? 1 : 0;
            container.css('opacity', opacity);
        }

        private updateNav(): void {
            if (this.isNavReady === false) {
                return;
            }

            if (this.hasEnoughWidth) {
                this.navPrev.hide();
                this.navNext.hide();
                this.navMenu.hide();
                this.movePrev();
            } else {
                this.navPrev.show();
                this.navNext.show();
                this.navMenu.show();
            }
        }

        private get isNavReady(): boolean {
            return !!(this.navPrev || this.navNext || this.navMenu);
        }
    }
}