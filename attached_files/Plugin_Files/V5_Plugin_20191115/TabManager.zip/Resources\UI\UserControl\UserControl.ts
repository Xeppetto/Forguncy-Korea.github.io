﻿namespace TabManager {

    export const enum GeneralCssNames {
        Disable = "FUI-disable",
        Show = "FUI-show",
        Checked = "FUI-checked",
        Selected = "FUI-selected",
        Focus = "FUI-focus"
    }

    /**
     * UserControl 所拥有的基本事件
     */
    export const enum UserControlEvents {
        Refresh = "Refresh",
        PropertyChanged = "PropertyChanged",
        UpdateSizeFromUI = "UpdateSizeFromUI",
        Dispose = "Dispose"
    }

    /**
     * 用户控件的 UI 构造函数
     */
    type UIConstructor<T, P> = { new(target: T): P }

    /**
     * UserControl具备这样的能力，即，当它已注册的属性的值被修改时，会dispatch相应的PropertyChanged事件
     * 这提供了这样的基础：当修改UserControl的注册属性时，可以通过UserControlEvents.PropertyChanged事件，通知到别处
     */
    export class UserControl extends EventDispatcher {
        // [绑定字段]
        id: string;
        enabled: boolean = true;
        visibility: boolean = true;
        focusable: boolean = false;
        isFocus: boolean = false;

        // [非绑定字段]
        userData: any;
        registedProperties: string[] = [];
        defaultUI: UIConstructor<UserControl, any>;

        constructor() {
            super();
            this.registDefaultProperties();
        }

        refresh(): this {
            this.dispatch(UserControlEvents.Refresh);
            return this;
        }

        identify(id: string) {
            this.id = id;
            return this;
        }

        show(): this {
            this.refresh();
            this.visibility = true;
            return this;
        }

        hide(): this {
            this.visibility = false;
            return this;
        }

        focus(): this {
            this.isFocus = true;
            return this;
        }

        blur(): this {
            this.isFocus = false;
            return this;
        }

        enable(): this {
            this.enabled = true;
            return this;
        }

        disable(): this {
            this.enabled = false;
            return this;
        }

        createUI<T extends UserControl, P extends IJQueryUI>(uiConstructor: UIConstructor<T, P> = this.defaultUI) {
            return new uiConstructor(this as any);
        }

        bindProperty<T extends UserControl>(targetElement: T, targetName: keyof T, sourceName: keyof this) {
            // Regist source name
            if (this.registedProperties.indexOf(sourceName as string) < 0) {
                this.registProperty(sourceName);
            }

            // Regist target name
            if (targetElement.registedProperties.indexOf(targetName as string) < 0) {
                targetElement.registProperty(targetName);
            }

            // Sync value immediately
            targetElement[targetName] = this[sourceName] as any;

            // Bind target value
            targetElement.on(UserControlEvents.PropertyChanged, (data, propertyName: string) => {
                if (propertyName === targetName && targetElement) {
                    this[sourceName] = targetElement[targetName] as any;
                }
            });

            // Bind source value
            this.on(UserControlEvents.PropertyChanged, (data, propertyName: string) => {
                if (propertyName === sourceName && targetElement) {
                    targetElement[targetName] = this[sourceName] as any;
                }
            });
        }

        registProperty<T extends keyof this>(propertyName: T, value: this[T] = this[propertyName]): void {
            const self = this;
            const privatePropertyName = `__${propertyName}`;
            this[privatePropertyName] = value;

            // 这里 相对于把原来的属性propertyName 强制修改为访问器属性了
            Object.defineProperty(this, propertyName, {
                get() {
                    return self[privatePropertyName];
                },
                set(newValue) {
                    if (newValue !== self[privatePropertyName]) {
                        self[privatePropertyName] = newValue;
                        self.onPropertyChanged(propertyName);
                    }
                }
            });
            this.registedProperties.push(propertyName as string);
        }

        protected registDefaultProperties() {
            this.registProperty("id");
            this.registProperty("enabled");
            this.registProperty("visibility");
            this.registProperty("focusable");
            this.registProperty("isFocus");
        }

        protected onPropertyChanged<T extends keyof this>(propertyName: T): void {
            this.dispatch(UserControlEvents.PropertyChanged, propertyName);
        }

    }

    export interface IJQueryUI {
        container: JQuery;
        refresh(): this;
        dispose(): void;
    }

    export class JQueryUIBase<T> implements IJQueryUI {
        // IJQueryUI.container
        container: JQuery;
        target: T;
        //modifiers: UIModifier<this>[];

        constructor(target: T) {
            this.target = target;

            this.createContainer();
            this.createContainerEvents();

            this.refresh();
        }

        // IJQueryUI.refresh()
        refresh(): this {
            this.container.empty();
            this.createChildren();
            return this;
        }

        // IJQueryUI.dispose
        dispose(): void { }

        protected createChildren(): void { }

        protected createContainer(): void {
            this.container = $('<div></div>');
        }

        protected createContainerEvents(): void { }

        protected addChild(jqueryUI: IJQueryUI, targetContainer: JQuery = this.container) {
            if (jqueryUI && targetContainer) {
                targetContainer.append(jqueryUI.container);
            }
        }
    }

    /**
     * 1.在ControlUIBase中，添加与T中已注册的属性同名的访问器属性，在其set方法里，做特定操作，比如，UI相关操作
     * 2.在ControlUIBase基类的构造函数中，绑定T的PropertyChanged事件，使得当修改T中的已注册属性时，能通过事件
     * 接收到这种改动，在事件中设置ControlUIBase的同名访问属性。这就实现了T中已注册的属性和UI的某种绑定
     */
    export class ControlUIBase<T extends UserControl> extends JQueryUIBase<T> {
        constructor(target: T) {
            super(target);

            this.target.on(UserControlEvents.Refresh, () => {
                this.refresh();
            });

            this.target.on(UserControlEvents.PropertyChanged, (propertyName: string) => {
                this[propertyName] = this.target[propertyName];
            });

            this.target.on(UserControlEvents.Dispose, () => {
                this.dispose();
            });
        }

        set id(value: string) {
            if (value === undefined || value === null || value === '') {
                this.container.removeAttr('id');
            } else {
                this.container.attr('id', value);
            }
        }

        set enabled(value: boolean) {
            if (value) {
                this.container.removeClass(GeneralCssNames.Disable);
                this.container.removeAttr("disabled");
                this.focusable = this.target.focusable;
            }
            else {
                this.container.addClass(GeneralCssNames.Disable);
                this.container.attr("disabled", "disabled");
                this.focusable = false;
            }
        }

        set visibility(value: boolean) {
            if (value) {
                this.container.show();
            } else {
                this.container.hide();
            }
        }

        set focusable(value: boolean) {
            if (value && this.target.enabled) {
                this.container.attr("tabindex", "0");
            }
            else {
                this.container.removeAttr("tabindex");
            }
        }

        set isFocus(value: boolean) {
            if (value && this.target.focusable) {
                this.container[0].focus();
            }
            else {
                this.container[0].blur();
            }
        }

        // override
        refresh(): this {
            super.refresh();
            this.initializeProperties();
            return this;
        }

        // override 
        protected createContainerEvents(): void {
            this.bindFocusAndBlurEvent();
        }

        protected initializeProperties(): void {
            this.target.registedProperties.forEach(propertyName => {
                this[propertyName] = this.target[propertyName];
            });
        }

        protected bindFocusAndBlurEvent(container: JQuery = this.container) {
            container.on("focus", () => {
                this.target.focus();
            });
            container.on("blur", () => {
                this.target.blur();
            });
        }
        
    }
}