﻿var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var TabManager;
(function (TabManager) {
    var TabContainerInstance = "TabContainerInstance";
    var TabUid = "TabUid";
    var TabMessageFlag = "TabMessageFlag";
    TabManager.TabPassValue = "TabPassValue";
    var TabUidGenerator = (function () {
        function TabUidGenerator() {
        }
        TabUidGenerator.next = function () {
            var topWindow = window.top;
            if (typeof topWindow[TabUid] === 'undefined') {
                topWindow[TabUid] = 0;
            }
            topWindow[TabUid] += 1;
            return topWindow[TabUid];
        };
        return TabUidGenerator;
    }());
    var Utils = (function () {
        function Utils() {
        }
        Utils.isEmpty = function (value) {
            if (value === undefined || value === null || value === '') {
                return true;
            }
            return false;
        };
        Utils.isNotEmpty = function (value) {
            return !Utils.isEmpty(value);
        };
        Utils.isEmptyData = function (data) {
            if (Utils.isEmpty(data)) {
                return true;
            }
            var sources = Object.keys(data);
            if (sources.length === 0) {
                return true;
            }
            return sources.every(function (s) { return Utils.isEmpty(data[s]); });
        };
        return Utils;
    }());
    var Tab = (function () {
        function Tab(isSelectPage, pageName, url, urlTitle, usedMode, data) {
            this.originalTitle = Utils.isEmpty(urlTitle) ? "" : urlTitle.toString().trim();
            this.isSelectPage = isSelectPage;
            this.pageName = Tab.getPageName(pageName);
            this.uid = TabUidGenerator.next();
            this.url = isSelectPage
                ? Tab.getUrlFromPage(this.pageName, data)
                : (Utils.isEmpty(url) ? "" : url.toString());
            this.openMode = usedMode;
            this.data = data ? data : null;
            this.displayedTitle = this.initTitle;
            this.canBeClosed = true;
        }
        Tab.prototype.setAlwaysOpen = function () {
            this.canBeClosed = false;
        };
        Object.defineProperty(Tab.prototype, "isValid", {
            get: function () {
                if (this.isSelectPage && Utils.isNotEmpty(this.pageName)) {
                    return true;
                }
                if (!this.isSelectPage && Utils.isNotEmpty(this.url)) {
                    return true;
                }
                return false;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Tab.prototype, "isValidUrl", {
            get: function () {
                var lowerUrl = this.url.toLowerCase();
                return lowerUrl.indexOf("http://") === 0 || lowerUrl.indexOf("https://") === 0;
            },
            enumerable: true,
            configurable: true
        });
        Tab.getPageName = function (pageName) {
            if (Utils.isEmpty(pageName)) {
                return "";
            }
            return pageName.toString().trim();
        };
        Object.defineProperty(Tab.prototype, "initTitle", {
            get: function () {
                if (this.originalTitle) {
                    return this.originalTitle;
                }
                if (this.isSelectPage) {
                    return this.pageName ? this.pageName : "...";
                }
                else {
                    return this.urlDisplayedTitle;
                }
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(Tab.prototype, "urlDisplayedTitle", {
            get: function () {
                var defaultTitle = "...";
                if (Utils.isEmpty(this.url)) {
                    return defaultTitle;
                }
                try {
                    var urlObject = new URL(this.url);
                    return urlObject.hostname;
                }
                catch (e) {
                    var url = this.url;
                    if (url.indexOf("http://") === 0) {
                        url = url.substr(7);
                    }
                    else if (url.indexOf("https://") === 0) {
                        url = url.substr(8);
                    }
                    var slashIndex = url.indexOf("/");
                    var queryIndex = url.indexOf("?");
                    var domainLength = Math.min(slashIndex, queryIndex);
                    if (domainLength === -1) {
                        return url;
                    }
                    return url.substr(0, domainLength);
                }
            },
            enumerable: true,
            configurable: true
        });
        Tab.getUrlFromPage = function (page, data) {
            if (Utils.isEmpty(page)) {
                return "";
            }
            if (page.indexOf("http://") === 0 || page.indexOf("https://") === 0) {
                return page;
            }
            var url = window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + page;
            if (data) {
                url += "?" + TabManager.TabPassValue + "=" + encodeURIComponent(JSON.stringify(data));
            }
            return url;
        };
        Tab.equalData = function (data1, data2) {
            if (Utils.isEmptyData(data1) && Utils.isEmptyData(data2)) {
                return true;
            }
            try {
                return JSON.stringify(data1) === JSON.stringify(data2);
            }
            catch (_a) {
                return false;
            }
        };
        Tab.exists = function (tab1, tab2, willCompareData) {
            if (willCompareData === void 0) { willCompareData = false; }
            if (tab1.isSelectPage !== tab2.isSelectPage) {
                return false;
            }
            if (tab1.isSelectPage) {
                if (tab1.pageName === tab2.pageName) {
                    if (willCompareData) {
                        return Tab.equalData(tab1.data, tab2.data);
                    }
                    return true;
                }
            }
            else {
                if (tab1.originalTitle === tab2.originalTitle
                    && tab1.url === tab2.url) {
                    return true;
                }
            }
            return false;
        };
        return Tab;
    }());
    TabManager.Tab = Tab;
    var TabContainer = (function (_super) {
        __extends(TabContainer, _super);
        function TabContainer(defaultPageInfo, tabStyle) {
            var _this = _super.call(this) || this;
            _this.defaultUI = TabManagerUI;
            _this.tabList = [];
            _this.registProperty("activeTab");
            _this.tabStyle = tabStyle;
            TabContainer.cacheTabContainerInstance(_this);
            TabContainer.addPostMessageEventListener();
            var DefaultPageOrURL = defaultPageInfo.DefaultPageOrURL, IsDefaultPageAlwaysOpen = defaultPageInfo.IsDefaultPageAlwaysOpen, IsURL = defaultPageInfo.IsURL;
            if (DefaultPageOrURL) {
                var newTab = IsURL
                    ? new Tab(false, '', DefaultPageOrURL, '', 0)
                    : new Tab(true, DefaultPageOrURL, '', '', 0);
                if (IsDefaultPageAlwaysOpen) {
                    newTab.setAlwaysOpen();
                }
                _this.addNewTab(newTab);
            }
            return _this;
        }
        TabContainer.addTab = function (tab) {
            if (!tab.isValid) {
                return;
            }
            if (!tab.isSelectPage && tab.isValidUrl === false) {
                alert(TabManager.ResourceHelper.getResourceString("alert_message_invalid_URL"));
                return;
            }
            var currentInstance = TabContainer.getCurrentInstance(window);
            if (!currentInstance) {
                return;
            }
            currentInstance.addOrReuseTab(tab);
        };
        TabContainer.getCurrentInstance = function (currentWindow) {
            var tabPluginInstance = currentWindow[TabContainerInstance];
            if (tabPluginInstance) {
                return tabPluginInstance;
            }
            var hasParent = currentWindow !== window.top;
            try {
                if (hasParent && currentWindow.parent.location.origin === location.origin) {
                    return TabContainer.getCurrentInstance(currentWindow.parent);
                }
            }
            catch (error) {
            }
            return null;
        };
        TabContainer.cacheTabContainerInstance = function (tabContainer) {
            var currentWindow = window;
            currentWindow[TabContainerInstance] = tabContainer;
        };
        TabContainer.addPostMessageEventListener = function () {
            if (window[TabMessageFlag]) {
                return;
            }
            window.addEventListener("message", function (ev) {
                var data = ev.data;
                if (data.type === "TITLE CHANGED") {
                    if (data.message && data.message.title && data.message.uid) {
                        TabContainer.refreshTitle(data.message.uid, data.message.title);
                    }
                }
                if (data.type === "CLOSE ACTIVE TAB") {
                    var currentInstance = TabContainer.getCurrentInstance(window);
                    if (!currentInstance) {
                        return;
                    }
                    currentInstance.closeTab(currentInstance.activeTab);
                }
            });
            window[TabMessageFlag] = true;
        };
        TabContainer.refreshTitle = function (uid, title) {
            var currentInstance = TabContainer.getCurrentInstance(window);
            if (!currentInstance) {
                return;
            }
            currentInstance.refreshTabTitle(uid, title);
        };
        TabContainer.findExistedTab = function (tabList, targetTab, willCompareData) {
            if (willCompareData === void 0) { willCompareData = false; }
            if (!tabList || tabList.length === 0) {
                return;
            }
            for (var i = 0; i < tabList.length; i++) {
                var currentTab = tabList[i];
                if (Tab.exists(currentTab, targetTab, willCompareData)) {
                    return currentTab;
                }
            }
            return null;
        };
        TabContainer.prototype.goPrevious = function () {
            var currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 < currentIndex) {
                this.active(this.tabList[currentIndex - 1]);
                return true;
            }
            return false;
        };
        TabContainer.prototype.goNext = function () {
            var currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 <= currentIndex && currentIndex < this.tabList.length - 1) {
                this.active(this.tabList[currentIndex + 1]);
                return true;
            }
            return false;
        };
        TabContainer.prototype.active = function (tab) {
            this.activeTab = tab;
        };
        TabContainer.prototype.addOrReuseTab = function (tab) {
            switch (tab.openMode) {
                case 0:
                    this.addNewTab(tab);
                    break;
                case 1: {
                    var existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        existedTab.data = tab.data;
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, true);
                    }
                    else {
                        this.addNewTab(tab);
                    }
                    break;
                }
                case 2: {
                    var existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        var willReload = !Tab.equalData(existedTab.data, tab.data);
                        existedTab.data = tab.data;
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, willReload);
                    }
                    else {
                        this.addNewTab(tab);
                    }
                    break;
                }
            }
        };
        TabContainer.prototype.closeTab = function (tab) {
            var isActiveTab = this.activeTab ? (tab.uid === this.activeTab.uid) : false;
            if (isActiveTab) {
                if (this.goNext() === false) {
                    this.goPrevious();
                }
            }
            var index = this.tabList.indexOf(tab);
            if (index >= 0) {
                this.tabList.splice(index, 1);
            }
            this.dispatch("TabsChange");
            this.dispatch("TabsClosed", [tab]);
        };
        TabContainer.prototype.refreshTabTitle = function (uid, title) {
            if (Utils.isEmpty(title)) {
                return;
            }
            var tab = this.findTabByUid(uid);
            var canChangeTitle = tab && Utils.isEmpty(tab.originalTitle) && tab.isSelectPage;
            if (canChangeTitle) {
                tab.displayedTitle = title;
                this.dispatch("TabsChange");
            }
        };
        TabContainer.prototype.findTabByUid = function (uid) {
            if (this.tabList && this.tabList.length > 0) {
                var uidNumber_1 = parseInt(uid);
                var tab = this.tabList.filter(function (t) { return t.uid === uidNumber_1; });
                if (tab.length === 0) {
                    return null;
                }
                return tab[0];
            }
            return null;
        };
        TabContainer.prototype.reuseTab = function (tab, willReload) {
            if (willReload === void 0) { willReload = false; }
            this.active(tab);
            if (willReload) {
                this.dispatch("ReloadTab", [tab]);
            }
        };
        TabContainer.prototype.addNewTab = function (tab) {
            this.tabList.push(tab);
            this.dispatch("TabsChange");
            this.active(tab);
        };
        return TabContainer;
    }(TabManager.UserControl));
    TabManager.TabContainer = TabContainer;
    var TabManagerUI = (function (_super) {
        __extends(TabManagerUI, _super);
        function TabManagerUI() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        TabManagerUI.prototype.createContainer = function () {
            this.container = $("<div class=\"" + "FTM-container" + "\"></div>");
        };
        TabManagerUI.prototype.createChildren = function () {
            this.addChild(this.target.createUI(TabManager.TabHeadUI));
            this.addChild(this.target.createUI(TabManager.TabContentUI));
        };
        return TabManagerUI;
    }(TabManager.ControlUIBase));
    TabManager.TabManagerUI = TabManagerUI;
})(TabManager || (TabManager = {}));
