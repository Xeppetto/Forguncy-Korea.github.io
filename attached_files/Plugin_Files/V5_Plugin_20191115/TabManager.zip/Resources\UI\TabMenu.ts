﻿namespace TabManager {
    export class TabMenuUI extends ControlUIBase<TabContainer> {
        set activeTab(value: Tab) {
            this.menuListWrap.find(`.${TabHeadClassNames.NavMenuListItem}`).removeClass(TabHeadClassNames.Active);
            if (value) {
                this.menuListWrap
                    .find(`.${TabHeadClassNames.NavMenuListItem}[data-uid=${value.uid}]`)
                    .addClass(TabHeadClassNames.Active);
            }
        }

        // override
        protected createContainer(): void {
            this.container = $(`<div class='${TabHeadClassNames.NavMenu}'></div>`);
            this.bindEvent = this.closeMenuListOnMouseDown.bind(this);
        }

        private menuListWrap: JQuery;
        private bindEvent;

        private closeMenuListOnMouseDown(ev: MouseEvent): void {
            const $t = $(ev.target);
            if ($t.hasClass(TabHeadClassNames.NavMenu)
                || $t.hasClass(TabHeadClassNames.NavListItemClose)
                || $t.hasClass(TabHeadClassNames.NavMenuWrap)
                || $t.hasClass(TabHeadClassNames.NavMenuList)
                || $t.hasClass(TabHeadClassNames.NavMenuListItem)) {
                return;
            }
            this.menuListWrap.hide();
        }

        get styleTemplateClassName(): string {
            if (!this.target.tabStyle) {
                return "";
            }
            return `TabManagerTabCellType-${this.target.tabStyle.Key}-TabItem`;
        }

        get menuItemClassName(): string {
            return `${TabHeadClassNames.NavMenuListItem} ${FragmentClassNames.Ellipsis} ${this.styleTemplateClassName}`;
        }

        // override
        protected createContainerEvents(): void {
            super.createContainerEvents();

            // tabs变化的时候 menu也要重刷一次
            this.target.on(TabManagerEvents.TabsChanged, () => {
                this.createMenus();
            });

            this.container.on('click', (ev: MouseEvent) => {
                if (this.target.tabList && this.target.tabList.length > 0) {
                    this.menuListWrap.show();
                }
                // 如果tab全部关闭 则不需要显示空的menuList
            });

            $("body").off("mousedown", this.bindEvent).on("mousedown", this.bindEvent);
        }

        // override 
        protected createChildren(): void {
            this.menuListWrap = $(`
<div class="${TabHeadClassNames.NavMenuWrap}">
    <ul class="${TabHeadClassNames.NavMenuList}"></ul>
</div>`);
            this.createMenus();
            this.container.append(this.menuListWrap);
        }

        private createMenus(): void {
            const newMenus = this.target.tabList.map(t => {
                const tab = $(`<li data-uid="${t.uid}" class="${this.menuItemClassName}" style="border-radius:0;box-shadow:none;border:none;"></li>`)
                    .on("click", (ev: MouseEvent) => {
                        this.target.active(t);
                        this.menuListWrap.hide();
                        ev.stopPropagation();
                    });

                tab.text(t.displayedTitle).attr("title", t.displayedTitle);

                if (t.canBeClosed) {
                    const closeIcon = $(`<i class="${TabHeadClassNames.NavListItemClose}"></i>`).on("click", (ev: MouseEvent) => {
                        this.target.closeTab(t);
                        this.menuListWrap.hide();
                    });

                    tab.append(closeIcon);
                }

                if (t === this.target.activeTab) {
                    tab.addClass(TabHeadClassNames.Active);
                }

                return tab;
            });

            this.menuListWrap.find('ul').empty();
            this.menuListWrap.find('ul').append(...newMenus);
        }

    }
}