﻿namespace TabManager {

    // 会影响到全局
    const TabContainerInstance = "TabContainerInstance";
    const TabUid = "TabUid";
    const TabMessageFlag = "TabMessageFlag";
    export const TabPassValue = "TabPassValue";

    export const enum MessageType {
        TitleChange = "TITLE CHANGED",
        CloseActiveTab = "CLOSE ACTIVE TAB",
    }

    export const enum TabManagerEvents {
        TabsClosed = "TabsClosed",
        ReloadTab = "ReloadTab",
        TabsChanged = "TabsChange",
        WindowResized = "WindowResized"
    }

    export const enum TabContainerClassNames {
        Container = "FTM-container"
    }

    class TabUidGenerator {
        static next(): number {
            const topWindow = window.top;
            if (typeof topWindow[TabUid] === 'undefined') {
                topWindow[TabUid] = 0;
            }

            topWindow[TabUid] += 1;

            return topWindow[TabUid];
        }
    }

    class Utils {
        static isEmpty(value: any): boolean {
            if (value === undefined || value === null || value === '') {
                return true;
            }
            return false;
        }

        static isNotEmpty(value: any): boolean {
            return !Utils.isEmpty(value);
        }

        static isEmptyData(data: TabData): boolean {
            if (Utils.isEmpty(data)) {
                return true;
            }

            const sources = Object.keys(data);
            if (sources.length === 0) {
                return true;
            }

            return sources.every(s => Utils.isEmpty(data[s]));
        }
    }

    export class Tab {
        originalTitle: string; // 是designer配置好的，在runtime传过来后，就不做任何修改
        pageName: string; // 记录原始的page name 并不一定是url
        url: string;
        uid: number;
        iframeContainer: JQuery;
        openMode: OpenTabMode;
        data: TabData;
        style: Forguncy.Plugin.CellTypeStyleTemplate;
        isSelectPage: boolean;
        displayedTitle: string; // 可能随着页面的跳转而改变
        canBeClosed: boolean;

        constructor(isSelectPage: boolean, pageName: string, url: string, urlTitle: string, usedMode: OpenTabMode, data?: TabData) {
            this.originalTitle = Utils.isEmpty(urlTitle) ? "" : urlTitle.toString().trim();
            this.isSelectPage = isSelectPage;
            this.pageName = Tab.getPageName(pageName);
            this.uid = TabUidGenerator.next();
            this.url = isSelectPage
                ? Tab.getUrlFromPage(this.pageName, data)
                : (Utils.isEmpty(url) ? "" : url.toString());
            this.openMode = usedMode;
            this.data = data ? data : null;
            this.displayedTitle = this.initTitle;
            this.canBeClosed = true;
        }

        setAlwaysOpen(): void {
            this.canBeClosed = false;
        }

        get isValid(): boolean {
            if (this.isSelectPage && Utils.isNotEmpty(this.pageName)) {
                return true;
            }

            if (!this.isSelectPage && Utils.isNotEmpty(this.url)) {
                return true;
            }

            return false;
        }

        /**
         * 简单判断合法的URL 只要以http://或者https://开头即可
         */
        get isValidUrl(): boolean {
            const lowerUrl = this.url.toLowerCase();
            return lowerUrl.indexOf("http://") === 0 || lowerUrl.indexOf("https://") === 0;
        }

        private static getPageName(pageName: string): string {
            if (Utils.isEmpty(pageName)) {
                return "";
            }
            // 确保不是number的pageName
            return pageName.toString().trim();
        }

        private get initTitle(): string {
            // 有title 就直接就用
            if (this.originalTitle) {
                return this.originalTitle;
            }

            if (this.isSelectPage) {
                // 如果没有title page就直接使用page name
                return this.pageName ? this.pageName : "...";
            } else {
                // 如果是url 则需要后期再次尝试截取 不过由于浏览器同源策略 可能还是获取不到
                return this.urlDisplayedTitle;
            }
        }

        private get urlDisplayedTitle(): string {
            const defaultTitle = "...";
            if (Utils.isEmpty(this.url)) {
                return defaultTitle;
            }

            try {
                const urlObject = new URL(this.url);
                return urlObject.hostname;
            } catch (e) {
                let url = this.url;
                if (url.indexOf("http://") === 0) {
                    url = url.substr(7);
                } else if (url.indexOf("https://") === 0) {
                    url = url.substr(8);
                }
                const slashIndex = url.indexOf("/");
                const queryIndex = url.indexOf("?");
                let domainLength = Math.min(slashIndex, queryIndex);
                if (domainLength === -1) {
                    return url;
                }
                return url.substr(0, domainLength);
            }

        }

        private static getUrlFromPage(page: string, data: TabData): string {
            if (Utils.isEmpty(page)) {
                return "";
            }

            if (page.indexOf("http://") === 0 || page.indexOf("https://") === 0) {
                return page;
            }

            let url = window.location.origin + Forguncy.Helper.SpecialPath.getBaseUrl() + page;
            if (data) {
                url += `?${TabPassValue}=${encodeURIComponent(JSON.stringify(data))}`; 
            }

            return url;
        }

        static equalData(data1: TabData, data2: TabData): boolean {
            // 由于TabData里没有方法 所以使用JSON字符串做简单比较
            if (Utils.isEmptyData(data1) && Utils.isEmptyData(data2)) {
                return true;
            }

            try {
                return JSON.stringify(data1) === JSON.stringify(data2);
            }
            catch {
                return false;
            }
        }

        static exists(tab1: Tab, tab2: Tab, willCompareData = false): boolean {
            if (tab1.isSelectPage !== tab2.isSelectPage) {
                return false;
            }

            if (tab1.isSelectPage) {
                // page name tab
                if (tab1.pageName === tab2.pageName) {
                    if (willCompareData) {
                        return Tab.equalData(tab1.data, tab2.data);
                    }
                    return true;
                }
            } else {
                // url tab
                if (tab1.originalTitle === tab2.originalTitle
                    && tab1.url === tab2.url) {
                    return true;
                }
            }

            return false;
        }
    }

    export class TabContainer extends UserControl {
        static addTab(tab: Tab): void {
            if (!tab.isValid) {
                return;
            }

            if (!tab.isSelectPage && tab.isValidUrl === false) {
                alert(ResourceHelper.getResourceString("alert_message_invalid_URL"));
                return;
            }

            const currentInstance = TabContainer.getCurrentInstance(window);

            if (!currentInstance) {
                return;
            }
            currentInstance.addOrReuseTab(tab);
        }

        /**
         * 一个页面上，限制只有一个TabPlugin
         * 如果在当前也找不到TabPlugin，就一直向上层browsing context寻找，直到找到window.top上
         * 如果一直没找到 就返回null
         * 
         * 如果一个browsing context有多个TabPlugin: 会使用最后添加的那个实例
         */
        private static getCurrentInstance(currentWindow: Window): TabContainer {
            const tabPluginInstance = currentWindow[TabContainerInstance];
            if (tabPluginInstance) {
                return tabPluginInstance;
            }

            const hasParent = currentWindow !== window.top;
            try {
                if (hasParent && currentWindow.parent.location.origin === location.origin) {
                    return TabContainer.getCurrentInstance(currentWindow.parent);
                }
            } catch (error) {
                // do nothing
            }

            return null;
        }

        static cacheTabContainerInstance(tabContainer: TabContainer): void {
            const currentWindow = window;
            currentWindow[TabContainerInstance] = tabContainer;
        }

        static addPostMessageEventListener(): void {
            if (window[TabMessageFlag]) {
                return;
            }

            window.addEventListener("message", (ev: MessageEvent) => {
                const data = ev.data as IWindowMessageData;

                if (data.type === MessageType.TitleChange) {
                    if (data.message && data.message.title && data.message.uid) {
                        TabContainer.refreshTitle(data.message.uid, data.message.title);
                    }
                }

                if (data.type === MessageType.CloseActiveTab) {
                    const currentInstance = TabContainer.getCurrentInstance(window);
                    if (!currentInstance) {
                        return;
                    }
                    currentInstance.closeTab(currentInstance.activeTab);
                }
            });

            window[TabMessageFlag] = true;
        }

        static refreshTitle(uid: string, title: string): void {
            const currentInstance = TabContainer.getCurrentInstance(window);
            if (!currentInstance) {
                return;
            }
            
            currentInstance.refreshTabTitle(uid, title);
        }

        private static findExistedTab(tabList: Tab[], targetTab: Tab, willCompareData = false): Tab {
            if (!tabList || tabList.length === 0) {
                return;
            }
            for (let i = 0; i < tabList.length; i++) {
                const currentTab = tabList[i];
                if (Tab.exists(currentTab, targetTab, willCompareData)) {
                    return currentTab;
                }
            }
            return null;
        }

        defaultUI = TabManagerUI;

        tabList: Tab[] = [];

        activeTab: Tab;

        tabStyle: Forguncy.Plugin.CellTypeStyleTemplate;

        constructor(defaultPageInfo: ICSharpTabCellType, tabStyle: Forguncy.Plugin.CellTypeStyleTemplate) {
            super();
            this.registProperty("activeTab");
            this.tabStyle = tabStyle;

            TabContainer.cacheTabContainerInstance(this);
            TabContainer.addPostMessageEventListener();

            const { DefaultPageOrURL, IsDefaultPageAlwaysOpen, IsURL } = defaultPageInfo;

            if (DefaultPageOrURL) {
                const newTab = IsURL
                    ? new Tab(false, '', DefaultPageOrURL, '', OpenTabMode.AlwaysOpenNewTab)
                    : new Tab(true, DefaultPageOrURL, '', '', OpenTabMode.AlwaysOpenNewTab);
                if (IsDefaultPageAlwaysOpen) {
                    newTab.setAlwaysOpen();
                }
                this.addNewTab(newTab);
            }
        }

        goPrevious(): boolean {
            let currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 < currentIndex) {
                this.active(this.tabList[currentIndex - 1]);
                return true;
            }
            return false;
        }

        goNext(): boolean {
            let currentIndex = this.tabList.indexOf(this.activeTab);
            if (0 <= currentIndex && currentIndex < this.tabList.length - 1) {
                this.active(this.tabList[currentIndex + 1]);
                return true;
            }
            return false;
        }

        active(tab: Tab): void {
            this.activeTab = tab;
        }

        addOrReuseTab(tab: Tab): void {
            switch (tab.openMode) {
                case OpenTabMode.AlwaysOpenNewTab:
                    this.addNewTab(tab);
                    break;
                case OpenTabMode.OpenExistedTabAlwaysReload: {
                    const existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        existedTab.data = tab.data; // 总是使用新data
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, true);
                    } else {
                        this.addNewTab(tab);
                    }
                    break;
                }
                case OpenTabMode.OpenExistedTabOnlyReloadWhenPassedDataChange: {
                    const existedTab = TabContainer.findExistedTab(this.tabList, tab);
                    if (existedTab) {
                        const willReload = !Tab.equalData(existedTab.data, tab.data);
                        existedTab.data = tab.data; // 总是使用新data
                        existedTab.url = tab.url;
                        this.reuseTab(existedTab, willReload);
                    } else {
                        this.addNewTab(tab);
                    }
                    break;
                }
            }
        }

        closeTab(tab: Tab): void {
            const isActiveTab = this.activeTab ? (tab.uid === this.activeTab.uid) : false;
            if (isActiveTab) {
                if (this.goNext() === false) {
                    this.goPrevious();
                }
            }

            const index = this.tabList.indexOf(tab);
            if (index >= 0) {
                this.tabList.splice(index, 1);
                //tab.iframeContainer.remove();
            }

            this.dispatch(TabManagerEvents.TabsChanged);
            this.dispatch(TabManagerEvents.TabsClosed, [tab]);
        }

        refreshTabTitle(uid: string, title): void {
            if (Utils.isEmpty(title)) {
                return;
            }

            const tab = this.findTabByUid(uid);
            const canChangeTitle = tab && Utils.isEmpty(tab.originalTitle) && tab.isSelectPage;
            if (canChangeTitle) {
                tab.displayedTitle = title;
                this.dispatch(TabManagerEvents.TabsChanged);
            }
        }

        private findTabByUid(uid: string): Tab {
            if (this.tabList && this.tabList.length > 0) {
                const uidNumber = parseInt(uid); 
                const tab = this.tabList.filter(t => t.uid === uidNumber);
                if (tab.length === 0) {
                    return null;
                }
                return tab[0];
            }
            return null;
        }

        private reuseTab(tab: Tab, willReload = false): void {
            this.active(tab);
            if (willReload) {
                this.dispatch(TabManagerEvents.ReloadTab, [tab]);
            }
        }

        private addNewTab(tab: Tab): void {
            this.tabList.push(tab);
            this.dispatch(TabManagerEvents.TabsChanged);
            this.active(tab);
        }
    }

    export class TabManagerUI extends ControlUIBase<TabContainer> {
        tabHeadContainer: JQuery;
        tabContentContainer: JQuery;

        // override
        protected createContainer(): void {
            this.container = $(`<div class="${TabContainerClassNames.Container}"></div>`);
        }

        // override
        protected createChildren(): void {
            this.addChild(this.target.createUI(TabHeadUI));
            this.addChild(this.target.createUI(TabContentUI));
        }

    }

}