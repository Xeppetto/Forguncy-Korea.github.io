﻿namespace TabManager {
    /**
     * An event system
     */
    export class Events {
        private _handlers: { [eventName: string]: Function[] };

        constructor() {
            this._handlers = {};
        }

        addHandler(eventName: string, handler: Function): Function {
            this._ensureEvent(eventName);
            this._handlers[eventName].push(handler);
            return handler;
        }

        removeHandler(eventName: string, handler: Function): void {
            const handlers = this._handlers[eventName];
            if (handlers) {
                const index = handlers.indexOf(handler);
                if (index !== -1) {
                    handlers.splice(index, 1);
                }
            }
        }

        raiseEvent(eventName: string, ...args): void {
            if (this._handlers[eventName]) {
                this._handlers[eventName].forEach(callback => callback(...args));
            }
        }

        release(): void {
            this._handlers = {};
        }

        private _ensureEvent(eventName: string): void {
            if (!this._handlers[eventName]) {
                this._handlers[eventName] = [];
            }
        }
    }
}