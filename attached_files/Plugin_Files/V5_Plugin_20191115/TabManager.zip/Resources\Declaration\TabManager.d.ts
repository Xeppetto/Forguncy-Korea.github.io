﻿type PassedValue = {
    Source: string,
    Target: string
}

type TabData = {
    [target: string]: string
};

interface ICsharpTabOpenCommandParam {
    TabManagerId: string; // runtime对tabplugin celltype的唯一标识
    UsedMode: number;
    IsSelectPage: boolean;
    PageName: string;
    UrlTitle: string;
    Url: string;

    PassedValueList: PassedValue[];
}

interface ICSharpTabCellType {
    DefaultPageOrURL: string;
    DefaultPageIcon?: string;
    IsDefaultPageAlwaysOpen: boolean;
    IsURL: boolean;
}

interface IWindowMessageData {
    type: string;
    message: {
        title: string;
        origin: string;
        uid: string;
    }
}
