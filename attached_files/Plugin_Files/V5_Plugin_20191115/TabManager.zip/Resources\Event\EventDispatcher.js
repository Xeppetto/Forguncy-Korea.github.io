﻿var TabManager;
(function (TabManager) {
    var EventDispatcher = (function () {
        function EventDispatcher() {
            this._events = new TabManager.Events();
        }
        EventDispatcher.prototype.on = function (eventName, handler) {
            this._events.addHandler(eventName, handler);
        };
        EventDispatcher.prototype.off = function (eventName, handler) {
            this._events.removeHandler(eventName, handler);
        };
        EventDispatcher.prototype.dispatch = function (eventName) {
            var args = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                args[_i - 1] = arguments[_i];
            }
            var _a;
            (_a = this._events).raiseEvent.apply(_a, [eventName].concat(args));
        };
        EventDispatcher.prototype.dispose = function () {
            this._events.release();
        };
        return EventDispatcher;
    }());
    TabManager.EventDispatcher = EventDispatcher;
})(TabManager || (TabManager = {}));
