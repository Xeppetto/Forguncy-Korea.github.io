﻿namespace TabManager {

    const enum TabContentClassNames {
        Content = "FTM-content",
        IFrame = "FTM-content-iframe"
    }

    export class TabContentUI extends ControlUIBase<TabContainer> {
        set activeTab(value: Tab) {
            this.container.find(`.${TabContentClassNames.IFrame}`).hide();
            this.showActiveIframe();
        }

        // override
        protected createContainer(): void {
            this.container = $(`<div class="${TabContentClassNames.Content}" id='page-content'></div>`);

            this.target.on(TabManagerEvents.TabsClosed, (tabs: Tab[]) => {
                tabs.forEach(tab => tab.iframeContainer && tab.iframeContainer.remove());
            });

            this.target.on(TabManagerEvents.ReloadTab, (tabs: Tab[]) => {
                tabs.forEach(tab => {
                    if (tab.iframeContainer) {
                        const iframe = tab.iframeContainer[0] as HTMLIFrameElement;
                        try {
                            iframe.contentWindow.location.href = tab.url; // reload
                        } catch {
                            // 避免跨域引起的error崩溃
                        }
                    }
                });
            });
        }

        private showActiveIframe(): void {
            const tab = this.target.activeTab;
            if (tab) {
                if (!tab.iframeContainer) {
                    //const url = encodeURIComponent(value.url);
                    tab.iframeContainer = $(`<iframe name="${tab.uid}" class="${TabContentClassNames.IFrame}" src="${tab.url}" />`);

                    this.container.append(tab.iframeContainer);
                }
                tab.iframeContainer.show();
            }
        }


    }
}