﻿namespace TabManager {
    export class EventDispatcher {
        private _events: Events;

        constructor() {
            this._events = new Events();
        }

        on(eventName: string, handler: Function): void {
            this._events.addHandler(eventName, handler);
        }

        off(eventName: string, handler: Function): void {
            this._events.removeHandler(eventName, handler);
        }

        dispatch(eventName: string, ...args): void {
            this._events.raiseEvent(eventName, ...args);
        }

        dispose(): void {
            this._events.release();
        }
    }
}