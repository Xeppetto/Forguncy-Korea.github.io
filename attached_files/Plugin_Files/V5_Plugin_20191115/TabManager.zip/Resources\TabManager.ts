﻿namespace TabManager {

    export const enum FragmentClassNames {
        Ellipsis = "FTM-f-ellipsis"
    }

    export class TabCellTypeStyleTemplateHelper extends CellTypeStyleTemplateHelperBase {
        constructor() {
            super();
            this.CellTypeString = "TabManager.TabManager";
            this.TemplateNameParts = ["TabItem"];
        }

        MapPartsNameToDom(container: JQuery): { [partName: string]: JQuery } {
            return {
                TABITEM: container.find(`.${TabHeadClassNames.NavListItem}`)
            };
        }

        OnTemplateStyleApplied(styleTemplate: Forguncy.Plugin.CellTypeStyleTemplate, container: JQuery): void {
            if (container) {
                // remove overflow hidden
                container.css("overflow", "visible");

                if (styleTemplate &&
                    styleTemplate.Styles &&
                    styleTemplate.Styles["TabItem"] &&
                    styleTemplate.Styles["TabItem"].SelectedStyle) {

                    var activeStyle = styleTemplate.Styles["TabItem"].SelectedStyle;
                    if (activeStyle.Background) {
                        const backgroundColor = Forguncy.ConvertToCssColor(activeStyle.Background);
                        container.find(`.${TabHeadClassNames.Nav}`).css('border-bottom-color', backgroundColor);
                    }
                }
            }
        }
    }

    export class TabCellType extends Forguncy.Plugin.CellTypeBase {
        tabManager: TabContainer;

        private static StyleTemplateHelper = new TabCellTypeStyleTemplateHelper();

        public getStyleTemplateHelper() {
            return TabCellType.StyleTemplateHelper;
        }

        // override
        public createContent(): JQuery {
            const cellType = this.CellElement.CellType as ICSharpTabCellType;
            const tabStyle = this.CellElement.StyleTemplate;
            const container = $(`<div style="width:100%;height:100%;" />`);

            this.tabManager = new TabContainer(cellType, tabStyle);

            container.append(this.tabManager.createUI().container);

            return container;
        }

        // override
        public onWindowResized(): void {
            this.tabManager.dispatch(TabManagerEvents.WindowResized);
        }
    }

    function getQuery(queryString: string) {
        const query = window.location.search.substring(1);
        const vars = query.split("&");
        for (let i = 0; i < vars.length; i++) {
            if (vars[i].indexOf(queryString) === 0) {
                try {
                    return decodeURIComponent(vars[i].substring(queryString.length + 1)); // 加1是等号 "pageContext="
                } catch (e) {
                    return null;
                }
            }
        }
    }

    Forguncy.Page.ready(function () {
        const passvalueStr = getQuery(TabPassValue);
        if (passvalueStr) {
            const passvalue = JSON.parse(passvalueStr, Common.dateReviver);//Fix BugSite7808: 如果不用common.dateReviver,JSON.parse(JSON.stringfy(new Date()))还是字符串
            for (let cellName in passvalue) {
                try {
                    const cell = Forguncy.Page.getCell(cellName);
                    if (cell) {
                        cell.setValue(passvalue[cellName]);
                    }
                } catch {
                    continue;
                }
            }
        }
    });

    class Common {
        public static dateReviver(key: any, value: any) {
            //方法来源：
            //https://msdn.microsoft.com/library/cc836466(v=vs.94).aspx
            var a;
            if (typeof value === 'string') {
                a = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
                if (a) {
                    return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4],
                        +a[5], +a[6]));
                }
            }
            return value;
        }
    }

    export class TabOpenCommand extends Forguncy.Plugin.CommandBase {

        public execute() {
            // Get setings
            const commandSettings = this.CommandParam as ICsharpTabOpenCommandParam;
            const urlTitle = this.evaluateFormula(commandSettings.UrlTitle);
            const pageName = this.evaluateFormula(commandSettings.PageName);
            const url = this.evaluateFormula(commandSettings.Url);
            const isSelectPage = commandSettings.IsSelectPage;

            const passedValueList = commandSettings.PassedValueList || [];
            const usedMode = commandSettings.UsedMode as OpenTabMode;

            const data: TabData = passedValueList.filter(item => {
                return item && item.Target;
            }).reduce((pre, cur) => {
                const source = this.evaluateFormula(cur.Source);
                const target = this.evaluateFormula(cur.Target);
                pre[target] = source;
                return pre;
            }, {});

            // Add command logic here
            const tab = new Tab(isSelectPage, pageName, url, urlTitle, usedMode, data);
            TabContainer.addTab(tab);
        }

    }

    // 与C#端的数据模型一致
    export const enum OpenTabMode {
        AlwaysOpenNewTab,
        OpenExistedTabAlwaysReload,
        OpenExistedTabOnlyReloadWhenPassedDataChange
    }

    export class ResourceHelper {
        static getResourceString(key: string): string {
            var culture; // CN, JA, KR or EN
            if (Forguncy && Forguncy.RS && Forguncy.RS.Culture) {
                culture = Forguncy.RS.Culture;
            } else {
                culture = Forguncy.ForguncySupportCultures.English; // default culture
            }
            if (ResourceHelper.resourceMap[culture]) {
                return ResourceHelper.resourceMap[culture][key];
            }
            return "";
        }

        static resourceMap = {
            CN: {
                alert_message_invalid_URL: "无效的URL！请提供以http://或者http://开头的完整URL。"
            },
            JA: {
                alert_message_invalid_URL: "Invalid URL! Please provide complete URL starting with http:// or https://"
            },
            KR: {
                alert_message_invalid_URL: "유효하지 않은 URL입니다! http:// or https:// 로 시작하는 정상적인 URL을 입력해 주세요."
            },
            EN: {
                alert_message_invalid_URL: "Invalid URL! Please provide complete URL starting with http:// or https://"
            }
        }
    }
}

Forguncy.Plugin.CellTypeHelper.registerCellType("TabManager.TabCellType, TabManager", TabManager.TabCellType);
Forguncy.Plugin.CommandFactory.registerCommand("TabManager.TabOpenCommand, TabManager", TabManager.TabOpenCommand);