﻿[
    {
        "Key": "_RS_Dark_ThemeStyle1",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Text 1 13",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Text_1_13",
                    "BorderRightString": "1px solid Text_1_13",
                    "BorderLeftString": "1px solid Text_1_13"
                },
                "HoverStyle": {
                    "FontColor": "Background 1 -20",
                    "Background": "Text 1 26"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1 -20",
                    "Background": "Text 1 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle2",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 1 20",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_1_20",
                    "BorderRightString": "1px solid Accent_1_20",
                    "BorderLeftString": "1px solid Accent_1_20"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 1 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 1 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle3",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 2 12",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_2_12",
                    "BorderRightString": "1px solid Accent_2_12",
                    "BorderLeftString": "1px solid Accent_2_12"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 2 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 2 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle4",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 3 12",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_3_12",
                    "BorderRightString": "1px solid Accent_3_12",
                    "BorderLeftString": "1px solid Accent_3_12"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 3 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 3 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle5",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 4 12",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_4_12",
                    "BorderRightString": "1px solid Accent_4_12",
                    "BorderLeftString": "1px solid Accent_4_12"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 4 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 4 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle6",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 5 12",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_5_12",
                    "BorderRightString": "1px solid Accent_5_12",
                    "BorderLeftString": "1px solid Accent_5_12"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 5 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 5 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Dark_ThemeStyle7",
        "Category": "_RS_Dark",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 6 12",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_6_12",
                    "BorderRightString": "1px solid Accent_6_12",
                    "BorderLeftString": "1px solid Accent_6_12"
                },
                "HoverStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 6 27"
                },
                "FocusStyle": {},
                "SelectedStyle": {
                    "FontColor": "Background 1",
                    "Background": "Accent 6 20"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle1",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Text 1 20",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Text_1_20",
                    "BorderRightString": "1px solid Text_1_20",
                    "BorderLeftString": "1px solid Text_1_20"
                },
                "HoverStyle": {
                    "Background": "Text 1 74"
                },
                "FocusStyle": {
                    "Background": "Text 1 70"
                },
                "SelectedStyle": {
                    "Background": "Text 1 70"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle2",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 1 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_1_14",
                    "BorderRightString": "1px solid Accent_1_14",
                    "BorderLeftString": "1px solid Accent_1_14"
                },
                "HoverStyle": {
                    "Background": "Accent 1 72"
                },
                "FocusStyle": {
                    "Background": "Accent 1 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 1 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle3",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 2 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_2_14",
                    "BorderRightString": "1px solid Accent_2_14",
                    "BorderLeftString": "1px solid Accent_2_14"
                },
                "HoverStyle": {
                    "Background": "Accent 2 72"
                },
                "FocusStyle": {
                    "Background": "Accent 2 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 2 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle4",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 3 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_3_14",
                    "BorderRightString": "1px solid Accent_3_14",
                    "BorderLeftString": "1px solid Accent_3_14"
                },
                "HoverStyle": {
                    "Background": "Accent 3 72"
                },
                "FocusStyle": {
                    "Background": "Accent 3 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 3 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle5",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 4 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_4_14",
                    "BorderRightString": "1px solid Accent_4_14",
                    "BorderLeftString": "1px solid Accent_4_14"
                },
                "HoverStyle": {
                    "Background": "Accent 4 72"
                },
                "FocusStyle": {
                    "Background": "Accent 4 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 4 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle6",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 5 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_5_14",
                    "BorderRightString": "1px solid Accent_5_14",
                    "BorderLeftString": "1px solid Accent_5_14"
                },
                "HoverStyle": {
                    "Background": "Accent 5 72"
                },
                "FocusStyle": {
                    "Background": "Accent 5 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 5 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    },
    {
        "Key": "_RS_Light_ThemeStyle7",
        "Category": "_RS_Light",
        "Styles": {
            "TabItem": {
                "NormalStyle": {
                    "FontColor": "Accent 6 14",
                    "Background": "Background 1",
                    "BorderRadiusString": "8px 8px 0 0",
                    "BorderTopString": "1px solid Accent_6_14",
                    "BorderRightString": "1px solid Accent_6_14",
                    "BorderLeftString": "1px solid Accent_6_14"
                },
                "HoverStyle": {
                    "Background": "Accent 6 72"
                },
                "FocusStyle": {
                    "Background": "Accent 6 67"
                },
                "SelectedStyle": {
                    "Background": "Accent 6 67"
                },
                "DisableStyle": {},
                "Transition": "0.15s"
            }
        }
    }
];
