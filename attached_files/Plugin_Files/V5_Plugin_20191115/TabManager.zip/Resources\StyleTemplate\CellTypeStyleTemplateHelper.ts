﻿interface StyleTemplates {
    [cellTypeString: string]: {
        [templateKey: string]: Forguncy.Plugin.CellTypeStyleTemplate
    }
}

namespace TabManager {
    export class CellTypeStyleTemplateHelperBase {
        CellTypeString: string;
        TemplateNameParts: string[];
        TemplateKey: string;
        Container: JQuery;

        ApplyTemplateStyle(styleTemplate: Forguncy.Plugin.CellTypeStyleTemplate, container: JQuery): void {
            if (!styleTemplate) {
                return;
            }

            // 保证container非空
            if (!container) {
                return;
            }

            const key = styleTemplate.Key;
            const templateDomParts = this.MapPartsNameToDom(container);

            for (let i = 0; i < this.TemplateNameParts.length; i++) {
                const partName = this.TemplateNameParts[i];
                const className = CellTypeStyleTemplateUtils
                    .FormatTemplateStyleClassName(this.CellTypeString, key, partName);
                const partDom = templateDomParts[partName];
                if (partDom) {
                    partDom.addClass(className);
                }
            }

            this.OnTemplateStyleApplied(styleTemplate, container);
        }

        MapPartsNameToDom(container: JQuery): { [partName: string]: JQuery } {
            return null;
        }

        OnTemplateStyleApplied(styleTemplate: Forguncy.Plugin.CellTypeStyleTemplate, container: JQuery): void { }

        Clear(): void { }
    }

    export class CellTypeStyleTemplateUtils {
        public static FormatTemplateStyleClassName(cellTypeName: string, templateKey: string, partName: string): string {
            return `${cellTypeName.replace(/\./g, '')}-${templateKey}-${partName}`;
        }
    }
}
