﻿var SmartPhoneCommand = (function (_super) {
    __extends(SmartPhoneCommand, _super);
    function SmartPhoneCommand() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    SmartPhoneCommand.prototype.execute = function () {

        // Get setings
        var param = this.CommandParam;
        var targetCellFormula = param.TargetCell;
        var cellLocation = this.getCellLocation(targetCellFormula);
        var cellInfo = JSON.stringify(cellLocation);

        var userAgent = window.navigator.userAgent;
        var iOS = /iPad|iPhone|iPod/;
        var Android = /Android/;
        if (new RegExp(iOS).test(userAgent)) {
            location.href = "hybrid:scancode?cellid=" + cellInfo;
        }
        else if (new RegExp(Android).test(userAgent)) {
            window.index.ScanCode(cellInfo);
        }
        else {
            var alertText = SmartPhoneCommand.getResourceString("scanCodeAlert");
            alert(alertText);
        }
    }

    SmartPhoneCommand.prototype.GetQRCode = function (cellInfo, qrcode) {
        var cellLocation = JSON.parse(cellInfo);
        Forguncy.Page.getCellByLocation(cellLocation).setValue(qrcode);
    }

    SmartPhoneCommand.resourceMap = {
        CN: {
            scanCodeAlert: "请使用手机客户端打开重试！"
        },
        JA: {
            scanCodeAlert: "モバイルアプリケーションを使用してこのページを開き、もう一度やり直してください。"
        },
        KR: {
            scanCodeAlert: "Please use Forguncy mobile client to perform this command."
        },
        EN: {
            scanCodeAlert: "Please use Forguncy mobile client to perform this command."
        }
    };

    SmartPhoneCommand.getResourceString = function (key) {
        var culture; // CN, JA, KR or EN
        if (Forguncy && Forguncy.RS && Forguncy.RS.Culture) {
            culture = Forguncy.RS.Culture;
        } else {
            culture = "EN"; // default culture
        }
        if (SmartPhoneCommand.resourceMap[culture]) {
            return SmartPhoneCommand.resourceMap[culture][key];
        }
        return "";
    }

    return SmartPhoneCommand;
}(Forguncy.CommandBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CommandFactory.registerCommand("SmartPhoneCommand.SmartPhoneCommand, SmartPhoneCommand", SmartPhoneCommand);