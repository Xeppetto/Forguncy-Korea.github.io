var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var ImportExportCSVCommand;
(function (ImportExportCSVCommand) {
    var ImportExportCSV = /** @class */ (function (_super) {
        __extends(ImportExportCSV, _super);
        function ImportExportCSV() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        ImportExportCSV.prototype.execute = function () {
            // Get settings
            var commandSettings = this.CommandParam;
            var importExportInfo = commandSettings.ImportExportInfo;
            if (!importExportInfo) {
                return;
            }
            var csvOperation = importExportInfo.CSVOperation;
            var listViewName = importExportInfo.ListViewName;
            var importExportHeaderRow = importExportInfo.ImportExportHeaderRow;
            var importMode = importExportInfo.ImportMode;
            var columns = importExportInfo.Columns;
            var pageID = this.getFormulaCalcContext().PageID;
            var pageInfo = Forguncy.Page.getSubPageInfoByPageID(pageID);
            var listview = pageInfo ? pageInfo.getListView(listViewName) : Forguncy.Page.getListView(listViewName, false);
            var cellLocations = this.getCellLocations(columns);
            if (!listview || cellLocations.length <= 0) {
                return;
            }
            var isPrimaryKeys = columns.map(function (c) {
                return c.IsPrimaryKey;
            });
            if (importExportHeaderRow) {
                var columnNames = columns.map(function (c) {
                    return c.CSVColumnName.trim();
                });
            }
            else if (csvOperation === CSVOperation.Import) {
                var csvColumnIndexs = columns.map(function (c) {
                    return c.CSVColumnIndex;
                });
            }
            var columnIndexListInListView = this.getColumnIndexs(listview, cellLocations);
            if (csvOperation === CSVOperation.Import) {
                this.importCSVFile(listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, isPrimaryKeys);
            }
            else {
                this.exportCSVFile(listViewName, listview, importExportHeaderRow, columnNames, columnIndexListInListView);
            }
        };
        ImportExportCSV.prototype.getCellLocations = function (columns) {
            var list = [];
            if (columns) {
                for (var i = 0; i < columns.length; i++) {
                    var cell = columns[i].ListViewColumnCell;
                    if (typeof (cell) === "string" && cell.length > 0 && cell[0] === "=") {
                        cell = this.getCellLocation(cell);
                        list.push(cell);
                    }
                    else {
                        list.push(null);
                    }
                }
            }
            return list;
        };
        ImportExportCSV.prototype.getColumnIndexs = function (listview, cellLocations) {
            var columnIndexList = [];
            var columns = listview.getMergedColumnInfos();
            for (var i = 0; i < cellLocations.length; i++) {
                if (cellLocations[i] === null) {
                    columnIndexList.push(-1);
                    continue;
                }
                var columnIndex = cellLocations[i].Column;
                var j = 0;
                for (j = 0; j < columns.length; j++) {
                    if (columns[j].DesignerColumnIndex === columnIndex) {
                        columnIndexList.push(j);
                        break;
                    }
                }
                if (j === columns.length) {
                    columnIndexList.push(-1);
                }
            }
            return columnIndexList;
        };
        ImportExportCSV.prototype.importCSVFile = function (listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, isPrimaryKeys) {
            var self = this;
            if ($("#importCSVFileInputID").length > 0) {
                $("#importCSVFileInputID").remove();
            }
            var fileInput = $("<input id='importCSVFileInputID' type='file' />");
            fileInput.css("display", "none");
            fileInput.attr("accept", ".csv");
            $("body").append(fileInput);
            $("#importCSVFileInputID").change(function (e) {
                var fileName = e.target.files[0];
                if (!fileName) {
                    return;
                }
                listview.showLoadingIndicator();
                var reader = new FileReader();
                reader.readAsDataURL(fileName);
                reader.onload = function (evt) {
                    var encoding = self.checkEncoding(evt.target.result);
                    window.Papa.parse(fileName, {
                        header: importExportHeaderRow,
                        //dynamicTyping: true,
                        encoding: encoding,
                        complete: function (results) {
                            try {
                                //remove empty rows in the end.
                                results.data = self.removeEmptyRowsInTheEnd(results.data);
                                //split csv array data
                                var splitInfo = self.splitCSVData(results.data, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, isPrimaryKeys);
                                if (!splitInfo) {
                                    return;
                                }
                                //cache listview orignal data
                                var cachedListViewData = [];
                                var listViewRowCount = listview.getRowCount();
                                var listViewColumnCount = listview.getMergedColumnInfos().length;
                                for (var r = 0; r < listViewRowCount; r++) {
                                    var rowData = [];
                                    for (var c = 0; c < listViewColumnCount; c++) {
                                        rowData.push(listview.getValue(r, c));
                                    }
                                    cachedListViewData.push(rowData);
                                }
                                //import data to listview.
                                var success = self.importDataToListView(results, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, splitInfo);
                                if (!success) {
                                    //rollback
                                    //delete rows
                                    var rowCount = listview.getRowCount();
                                    for (var row = rowCount - 1; row >= 0; row--) {
                                        listview.deleteRow(row);
                                    }
                                    //add orignal rows
                                    for (var i = 0; i < cachedListViewData.length; i++) {
                                        listview.addNewRow(cachedListViewData[i]);
                                    }
                                    listview.reload();
                                }
                            }
                            finally {
                                listview.hiddenLoadingIndicator();
                            }
                        }
                    });
                };
            });
            if (!Forguncy.ForguncyData.IsAutoTest) {
                $("#importCSVFileInputID").click();
            }
        };
        ImportExportCSV.prototype.checkEncoding = function (dataStr) {
            //这种方式得到的是一种二进制串
            var str = atob(dataStr.split(";base64,")[1]);
            //要用二进制格式
            var encoding = window.jschardet.detect(str);
            encoding = encoding.encoding;
            if (encoding === "windows-1252") { //有时会识别错误（如UTF8的中文二字）
                encoding = "ANSI";
            }
            return encoding;
        };
        ImportExportCSV.prototype.removeEmptyRowsInTheEnd = function (data) {
            var invalidRowCount = 0;
            for (var i = data.length - 1; i >= 0; i--) {
                var newRowData = data[i];
                if (!newRowData || newRowData.length === 0) {
                    invalidRowCount++;
                    continue;
                }
                var isEmptyRow = true;
                for (var key in newRowData) {
                    if (newRowData[key] !== undefined && newRowData[key] !== null && newRowData[key] !== "") {
                        isEmptyRow = false;
                        break;
                    }
                }
                if (isEmptyRow) {
                    invalidRowCount++;
                }
                else {
                    break;
                }
            }
            if (invalidRowCount > 0) {
                var validRowCount = data.length - invalidRowCount;
                data = data.slice(0, validRowCount);
            }
            return data;
        };
        ImportExportCSV.prototype.splitCSVData = function (csvData, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, importMode, isPrimaryKeys) {
            if (importMode === ImportMode.Add) {
                return {
                    addRowIndexArrayInCSV: csvData.map(function (d, index) {
                        return index;
                    })
                };
            }
            var pkInfos = this.getPKValuesInfo(csvData, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, isPrimaryKeys);
            var pkValuesInCSV = pkInfos.pkValuesInCSV;
            var pkValuesInListView = pkInfos.pkValuesInListView;
            var pkValuesStrInCSV = pkValuesInCSV.map(function (d) {
                return JSON.stringify(d);
            });
            //check primary key unique
            var existSameKey = pkValuesStrInCSV.some(function (v, i, a) { return a.indexOf(v) !== i; });
            if (existSameKey) {
                alert(this.getRS().Error_ExistSameKeys);
                return null;
            }
            var pkValuesStrInListView = pkValuesInListView.map(function (element) {
                return JSON.stringify(element);
            });
            var addRowIndexArrayInCSV = [];
            var editRowIndexArrayInCSV = [];
            var editRowIndexArrayInListView = [];
            for (var i = 0; i < pkValuesInCSV.length; i++) {
                var findElement = JSON.stringify(pkValuesInCSV[i]);
                var index = pkValuesStrInListView.indexOf(findElement);
                if (index === -1) {
                    addRowIndexArrayInCSV.push(i);
                }
                else {
                    while (index !== -1) {
                        editRowIndexArrayInCSV.push(i);
                        editRowIndexArrayInListView.push(index);
                        index = pkValuesStrInListView.indexOf(findElement, index + 1);
                    }
                }
            }
            if (importMode === ImportMode.Merge) {
                return {
                    addRowIndexArrayInCSV: addRowIndexArrayInCSV,
                    editRowIndexArrayInCSV: editRowIndexArrayInCSV,
                    editRowIndexArrayInListView: editRowIndexArrayInListView
                };
            }
            var deleteRowIndexArrayInListView = [];
            for (i = 0; i < pkValuesInListView.length; i++) {
                index = pkValuesStrInCSV.indexOf(JSON.stringify(pkValuesInListView[i]));
                if (index === -1) {
                    deleteRowIndexArrayInListView.push(i);
                }
            }
            return {
                addRowIndexArrayInCSV: addRowIndexArrayInCSV,
                editRowIndexArrayInCSV: editRowIndexArrayInCSV,
                editRowIndexArrayInListView: editRowIndexArrayInListView,
                deleteRowIndexArrayInListView: deleteRowIndexArrayInListView
            };
        };
        ImportExportCSV.prototype.getPKValuesInfo = function (csvData, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, isPrimaryKeys) {
            var pkNameOrIndexInCSV = [];
            var pkColumnIndexInListView = [];
            for (var i = 0; i < isPrimaryKeys.length; i++) {
                if (!isPrimaryKeys[i]) {
                    continue;
                }
                var cNameOrIndex = importExportHeaderRow ? columnNames[i] : csvColumnIndexs[i] - 1;
                pkNameOrIndexInCSV.push(cNameOrIndex);
                pkColumnIndexInListView.push(columnIndexListInListView[i]);
            }
            var pkValuesInCSV = [];
            for (i = 0; i < csvData.length; i++) {
                var rowData = csvData[i];
                var pkValuesInRow = [];
                for (var j = 0; j < pkNameOrIndexInCSV.length; j++) {
                    var tempPKValue = rowData[pkNameOrIndexInCSV[j]];
                    if (tempPKValue === "" || tempPKValue === undefined) {
                        tempPKValue = null;
                    }
                    pkValuesInRow.push(tempPKValue);
                }
                pkValuesInCSV.push(pkValuesInRow);
            }
            var pkValuesInListView = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                pkValuesInRow = [];
                for (j = 0; j < pkColumnIndexInListView.length; j++) {
                    var cVal = listview.getValue(r, pkColumnIndexInListView[j]);
                    if (cVal === "" || cVal === undefined) {
                        cVal = null;
                    }
                    if (cVal) {
                        cVal = cVal + "";
                    }
                    pkValuesInRow.push(cVal);
                }
                pkValuesInListView.push(pkValuesInRow);
            }
            return {
                pkValuesInCSV: pkValuesInCSV,
                pkValuesInListView: pkValuesInListView
            };
        };
        ImportExportCSV.prototype.importDataToListView = function (results, listview, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView, splitInfo) {
            try {
                Forguncy.Page.suspendCalc();
                if (importExportHeaderRow) {
                    var noFindColumns = [];
                    if (results.meta.fields) {
                        results.meta.fields = results.meta.fields.map(function (f) {
                            return f.trim();
                        });
                    }
                    for (var i = 0; i < columnNames.length; i++) {
                        if (results.meta.fields) {
                            if (results.meta.fields.some(function (fieldName) { return fieldName === columnNames[i]; })) {
                                continue;
                            }
                            noFindColumns.push(columnNames[i]);
                        }
                        else {
                            noFindColumns = columnNames;
                        }
                    }
                    if (noFindColumns.length > 0) {
                        alert(this.getRS().Error_ColumnNameNotMatch.replace("{0}", noFindColumns.join(",")));
                        return false;
                    }
                }
                //edit
                if (splitInfo.editRowIndexArrayInListView && splitInfo.editRowIndexArrayInListView.length > 0) {
                    for (var k = 0; k < splitInfo.editRowIndexArrayInListView.length; k++) {
                        var lRowIndex = splitInfo.editRowIndexArrayInListView[k];
                        var cRowIndex = splitInfo.editRowIndexArrayInCSV[k];
                        var cRowData = results.data[cRowIndex];
                        var newRowData = this.getNewRowData(cRowData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView);
                        for (var c in newRowData) {
                            try {
                                listview.setText(lRowIndex, parseInt(c), newRowData[c]);
                            }
                            catch (e) {
                                this.alertErrorMessage(e, cRowIndex, importExportHeaderRow);
                                return false;
                            }
                        }
                    }
                }
                //delete
                if (splitInfo.deleteRowIndexArrayInListView && splitInfo.deleteRowIndexArrayInListView.length > 0) {
                    for (i = splitInfo.deleteRowIndexArrayInListView.length - 1; i >= 0; i--) {
                        lRowIndex = splitInfo.deleteRowIndexArrayInListView[i];
                        listview.deleteRow(lRowIndex);
                    }
                }
                //add
                if (splitInfo.addRowIndexArrayInCSV && splitInfo.addRowIndexArrayInCSV.length > 0) {
                    for (i = 0; i < splitInfo.addRowIndexArrayInCSV.length; i++) {
                        cRowIndex = splitInfo.addRowIndexArrayInCSV[i];
                        cRowData = results.data[cRowIndex];
                        try {
                            var rowData = this.getNewRowData(cRowData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView);
                            //Add new row data
                            listview.addNewRow(rowData, true);
                        }
                        catch (e) {
                            this.alertErrorMessage(e, cRowIndex, importExportHeaderRow);
                            return false;
                        }
                    }
                }
                return true;
            }
            finally {
                Forguncy.Page.resumeCalc();
            }
        };
        ImportExportCSV.prototype.getRS = function () {
            var culture = Forguncy.RS.Culture;
            if (culture === 'CN') {
                return window.RS_CN;
            }
            else if (culture === 'JA') {
                return window.RS_JP;
            }
            else if (culture === 'KR') {
                return window.RS_KO;
            }
            return window.RS_EN;
        };
        ImportExportCSV.prototype.getNewRowData = function (rowData, importExportHeaderRow, columnNames, csvColumnIndexs, columnIndexListInListView) {
            var newRowData = [];
            for (var i = 0; i < columnIndexListInListView.length; i++) {
                var c = columnIndexListInListView[i];
                if (c === -1) {
                    continue;
                }
                var cNameOrIndex = importExportHeaderRow === true ? columnNames[i] : csvColumnIndexs[i] - 1;
                var tempValue = rowData[cNameOrIndex];
                if (tempValue === null || tempValue === undefined || tempValue === "") {
                    tempValue = null;
                }
                newRowData[c] = tempValue;
            }
            return newRowData;
        };
        ImportExportCSV.prototype.alertErrorMessage = function (e, rowIndex, importExportHeaderRow) {
            var csvRowIndex = rowIndex + 1;
            if (importExportHeaderRow) {
                csvRowIndex += 1;
            }
            alert(this.getRS().Error_DetailInfo.replace("{0}", e.CellValue).replace("{1}", csvRowIndex).replace("{2}", e.message));
        };
        ImportExportCSV.prototype.exportCSVFile = function (csvFileName, listview, importExportHeaderRow, columnNames, columnIndexListInListView) {
            var data = [];
            var rowCount = listview.getRowCount();
            for (var r = 0; r < rowCount; r++) {
                var rowData = [];
                for (var i = 0; i < columnIndexListInListView.length; i++) {
                    var c = columnIndexListInListView[i];
                    if (c === -1) {
                        var val = null;
                    }
                    else {
                        val = listview.getText(r, c);
                    }
                    rowData.push(val);
                }
                data.push(rowData);
            }
            if (importExportHeaderRow) {
                var csv = window.Papa.unparse({
                    fields: columnNames,
                    data: data
                });
            }
            else {
                csv = window.Papa.unparse({
                    data: data
                });
            }
            //download csv file
            var fileName = csvFileName + ".csv";
            var BOM = "\uFEFF";
            var blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
            if (window.navigator.msSaveOrOpenBlob) // IE hack; see http://msdn.microsoft.com/en-us/library/ie/hh779016.aspx
                window.navigator.msSaveBlob(blob, fileName);
            else {
                var a = window.document.createElement("a");
                a.href = window.URL.createObjectURL(blob);
                a.download = fileName;
                document.body.appendChild(a);
                a.click(); // IE: "Access is denied"; see: https://connect.microsoft.com/IE/feedback/details/797361/ie-10-treats-blob-url-as-cross-origin-and-denies-access
                document.body.removeChild(a);
            }
        };
        return ImportExportCSV;
    }(Forguncy.Plugin.CommandBase));
    ImportExportCSVCommand.ImportExportCSV = ImportExportCSV;
    var CSVOperation;
    (function (CSVOperation) {
        CSVOperation[CSVOperation["Import"] = 0] = "Import";
        CSVOperation[CSVOperation["Export"] = 1] = "Export";
    })(CSVOperation || (CSVOperation = {}));
    var ImportMode;
    (function (ImportMode) {
        ImportMode[ImportMode["Add"] = 0] = "Add";
        ImportMode[ImportMode["Merge"] = 1] = "Merge";
        ImportMode[ImportMode["Replace"] = 2] = "Replace";
    })(ImportMode || (ImportMode = {}));
})(ImportExportCSVCommand || (ImportExportCSVCommand = {}));
// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.Plugin.CommandFactory.registerCommand("ImportExportCSV.ImportExportCSV, ImportExportCSV", ImportExportCSVCommand.ImportExportCSV);
