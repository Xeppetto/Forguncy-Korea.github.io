﻿var RS_JP = {
    Error_DetailInfo: "CSVファイルの {1} 行目の値 {0} が不正な値です。\r\nエラーメッセージ：{2}",
    Error_ColumnNameNotMatch: "次の列名がCSVファイルの最初の行に存在しません。：［{0}］",
    Error_ExistSameKeys: "Exists same reference column values in csv file data and please ensure the reference column values is unique."
};

var RS_CN = {
    Error_DetailInfo: "CSV文件中第'{1}'行中的值'{0}'不合法；\r\n错误信息：{2}",
    Error_ColumnNameNotMatch: "CSV文件第一行中未发现以下列名：【{0}】。",
    Error_ExistSameKeys: "CSV文件中基准列存在相同的数据，请确保基准列的数据是唯一的。"
};

var RS_KO = {
    Error_DetailInfo: "CSV 파일의 '{1}'행에있는 '{0}'값이 잘못되었습니다.\r\nError message:{2}",
    Error_ColumnNameNotMatch: "CSV 파일의 첫 번째 행에 이러한 열 이름을 찾을 수 없습니다.:[{0}].",
    Error_ExistSameKeys: "CSV파일 데이터에 동일한 키 값이 존재합니다. Primary Key 값은 중복되지 않아야 합니다."
};

var RS_EN = {
    Error_DetailInfo: "The value '{0}' is invalid which in row '{1}' in csv file.\r\nError message:{2}",
    Error_ColumnNameNotMatch: "Not found such column names in first row of csv file:[{0}].",
    Error_ExistSameKeys: "Exists same reference column values in csv file data and please ensure the reference column values is unique."
};