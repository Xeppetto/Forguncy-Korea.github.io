var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Forguncy;
(function (Forguncy) {
    var HtmlRichEditor;
    (function (HtmlRichEditor_1) {
        var HtmlRichEditor = /** @class */ (function (_super) {
            __extends(HtmlRichEditor, _super);
            function HtmlRichEditor() {
                var _this = _super !== null && _super.apply(this, arguments) || this;
                _this._enabled = true;
                _this._readOnly = false;
                _this._editorID = '';
                return _this;
            }
            HtmlRichEditor.prototype.createContent = function () {
                this._initEditorID();
                var container = $("<div class=\"FGCHtmlRichEditor\" style=\"height:100%\"><div id=" + this._editorID + "></div></div>");
                var hiddenDom = $("<div id=" + this.ID + " style=\"display:none;\"></div>");
                container.append(hiddenDom);
                return container;
            };
            HtmlRichEditor.prototype._initEditorID = function () {
                this._editorID = this.ID + '_' + this['_pageID']; // _pageID 这属性其实没有暴露出来 但用这个方法取
            };
            HtmlRichEditor.prototype.editor = function () {
                return tinymce.get(this._editorID);
            };
            HtmlRichEditor.prototype.getValueFromElement = function () {
                if (this._destroyed) {
                    return;
                }
                return this.editor().getContent();
            };
            HtmlRichEditor.prototype.setValueToElement = function (element, value) {
                if (this._destroyed) {
                    return;
                }
                if (value === null) {
                    value = "";
                }
                var self = this;
                var control = this.editor();
                if (control.initialized) {
                    control.undoManager.clear();
                    control.setContent(value);
                }
                else {
                    setTimeout(function () {
                        self.setValueToElement(element, value);
                    }, 500);
                }
                if (HtmlRichEditor._iOSPattern.test(navigator.userAgent)) {
                    var iframe = $('iframe#' + this._editorID + '_ifr');
                    if (iframe.length > 0) {
                        var body = iframe[0]['contentDocument'].getElementsByTagName('body')[0];
                        // refer: https://css-tricks.com/snippets/css/momentum-scrolling-on-ios-overflow-elements/
                        var $div = $("<div style='height:" + this.CellElement.Height + "px; overflow-y:scroll;-webkit-overflow-scrolling:touch;'></div>");
                        $div.append(body.children);
                        $(body).append($div);
                    }
                }
            };
            HtmlRichEditor.prototype.hasFocus = function () {
                return this._hasFocus;
            };
            HtmlRichEditor.prototype.setFocus = function () {
                if (this._readOnly) {
                    return;
                }
                this.editor().focus();
            };
            HtmlRichEditor.prototype.disable = function () {
                _super.prototype.disable.call(this);
                this._enabled = false;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.enable = function () {
                _super.prototype.enable.call(this);
                this._enabled = true;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.setReadOnly = function (value) {
                _super.prototype.setReadOnly.call(this, value);
                this._readOnly = value;
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.updateEditorMode = function () {
                var editor = this.editor();
                if (!editor) {
                    return;
                }
                var mode = this._enabled && !this._readOnly ? 'design' : 'readonly';
                editor.setMode(mode);
            };
            HtmlRichEditor.prototype.destroy = function () {
                this._destroyed = true;
                try {
                    for (var i = tinymce.editors.length - 1; i > -1; i--) {
                        var ed_id = tinymce.editors[i].id;
                        if (ed_id == this._editorID) {
                            tinymce.execCommand("mceRemoveEditor", true, ed_id);
                        }
                    }
                }
                catch (_a) {
                    // Do nothing
                }
            };
            HtmlRichEditor.prototype.onLoad = function () {
                var cellTypeMetadata = this.CellElement.CellType;
                var showToolBars = cellTypeMetadata.ShowToolBars;
                var lang = 'ja';
                if (Forguncy.RS) {
                    if (Forguncy.RS.Culture === "CN" /* Chinese */) {
                        lang = 'zh_CN';
                    }
                    else if (Forguncy.RS.Culture === "KR" /* Korean */) {
                        lang = 'ko_KR';
                    }
                }
                if (showToolBars) {
                    tinymce.init({
                        selector: '#' + this._editorID,
                        language: lang,
                        plugins: [
                            'paste',
                            'textcolor colorpicker link lists code print table preview image imagetools'
                        ],
                        branding: false,
                        elementpath: false,
                        menubar: false,
                        resize: false,
                        statusbar: false,
                        paste_data_images: true,
                        toolbar: [
                            'undo redo | fontselect | fontsizeselect | backcolor forecolor | bullist numlist table | link  image',
                            'styleselect | bold italic underline strikethrough | alignleft aligncenter alignright alignjustify | outdent indent | code | print preview'
                        ],
                        style_formats: [
                            {
                                title: 'Headers',
                                items: [
                                    { title: 'Header 1', format: 'h1' },
                                    { title: 'Header 2', format: 'h2' },
                                    { title: 'Header 3', format: 'h3' },
                                    { title: 'Header 4', format: 'h4' },
                                    { title: 'Header 5', format: 'h5' },
                                    { title: 'Header 6', format: 'h6' }
                                ]
                            },
                            {
                                title: 'Inline',
                                items: [
                                    { title: 'Superscript', icon: 'superscript', format: 'superscript' },
                                    { title: 'Subscript', icon: 'subscript', format: 'subscript' },
                                    { title: 'Code', icon: 'code', format: 'code' }
                                ]
                            },
                            {
                                title: 'Blocks',
                                items: [
                                    { title: 'Paragraph', format: 'p' },
                                    { title: 'Blockquote', format: 'blockquote' },
                                    { title: 'Div', format: 'div' }
                                ]
                            }
                        ],
                        width: "100%",
                        height: "calc(100% - 68px)",
                        setup: this.onSetup.bind(this)
                    });
                }
                else {
                    tinymce.init({
                        selector: '#' + this._editorID,
                        language: lang,
                        branding: false,
                        elementpath: false,
                        menubar: false,
                        resize: false,
                        statusbar: false,
                        toolbar: false,
                        width: "100%",
                        height: "100%",
                        setup: this.onSetup.bind(this)
                    });
                }
                this.updateEditorMode();
            };
            HtmlRichEditor.prototype.onSetup = function (ed) {
                var cellType = this;
                ed.on('Blur', function () {
                    cellType._hasFocus = false;
                    cellType.commitValue();
                });
                ed.on('Focus', function () {
                    cellType._hasFocus = true;
                });
            };
            HtmlRichEditor._iOSPattern = /iPad|iPhone|iPod/;
            return HtmlRichEditor;
        }(Forguncy.Plugin.CellTypeBase));
        HtmlRichEditor_1.HtmlRichEditor = HtmlRichEditor;
    })(HtmlRichEditor = Forguncy.HtmlRichEditor || (Forguncy.HtmlRichEditor = {}));
})(Forguncy || (Forguncy = {}));
Forguncy.Plugin.CellTypeHelper.registerCellType("HtmlRichEditor.HtmlRichEditor, HtmlRichEditor", Forguncy.HtmlRichEditor.HtmlRichEditor);
//# sourceMappingURL=HtmlRichEditor.js.map