﻿using GrapeCity.Forguncy.CellTypes;
using GrapeCity.Forguncy.Plugin;
using GrapeCity.Forguncy.Commands;
using System;
using System.Collections.Generic;

namespace ForguncyPluginDataTypeTest
{
    //포건시 셀유형 선택 시 왼쪽에 표시할 아이콘의 모양을 정의하는 부분입니다.
    [Icon("pack://application:,,,/ForguncyPluginDataTypeTest;component/Resources/ForguncyPluginDataTypeIcon.png")]
    public class DemoCellType : CellType
    {
        //포건시 셀유형 선택 목록에 표시되는 이름을 정의합니다.
        public override string ToString()
        {
            return "포건시 플러그인 자료형 예제"; 
        }

        //포건시 플러그인 DataType 중 String을 이용합니다.
        public string MyStringProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 int를 이용합니다.
        public int MyIntProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 boolean을 이용합니다.
        public bool MyBoolProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 double을 이용합니다.
        public double MyDoubleProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 enum을 이용합니다.
        public MyEnum MyEnumProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 timespan을 이용합니다.
        public TimeSpan MyTimeSpanProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 image value를 이용합니다.
        public ImageValue MyImageProperty
        {
            get; set;
        }

        //포건시 플러그인 DataType 중 command list를 이용합니다.
        public List<Command> MyCommandListProperty
        {
            get; set;
        }
    }

    //위에서 선언한 enum 관련 표시할 값을 정합니다.
    public enum MyEnum
    {
        EnumValue1,
        EnumValue2,
        EnumValue3
    }
}
