﻿var ForguncyPluginDataTypeTest = (function (_super) {
    __extends(ForguncyPluginDataTypeTest, _super);
    function ForguncyPluginDataTypeTest() {
        return _super !== null && _super.apply(this, arguments) || this;
    }

    ForguncyPluginDataTypeTest.prototype.createContent = function () {
        var self = this;

        var element = this.CellElement;
        var cellTypeMetaData = element.CellType;
        var container = $("<div id='" + this.ID + "'></div>");

        var innerContainer = $(`
<div style='width:100%;height:100%'>
    Custom Cell
</div>`);

        container.append(innerContainer);

        return container;
    };

    ForguncyPluginDataTypeTest.prototype.getValueFromElement = function () {
        return null;
    };

    ForguncyPluginDataTypeTest.prototype.setValueToElement = function (element, value) {

    };

    ForguncyPluginDataTypeTest.prototype.disable = function () {
        _super.prototype.disable.call(this);
    };

    ForguncyPluginDataTypeTest.prototype.enable = function () {
        _super.prototype.enable.call(this);
    };

    return ForguncyPluginDataTypeTest;
}(Forguncy.CellTypeBase));

// Key format is "Namespace.ClassName, AssemblyName"
Forguncy.CellTypeHelper.registerCellType("ForguncyPluginDataTypeTest.ForguncyPluginDataTypeTest, ForguncyPluginDataTypeTest", ForguncyPluginDataTypeTest);